var scheduler = require('node-schedule');
var mysql= require('mysql');
var db_connection= require('../routes/db_connection');
var connection= mysql.createConnection(db_connection);


scheduler.scheduleJob('1 0 1 * *',function(){

  
    connection.query('CALL UPDATE_REVENUE()',
    
    function(err, rows,fields) {
        if (err) {
            console.log(err);
        }
    
        else {
        
        console.log(new Date()+" Procedure Complete");
        
        }
});
});





/*
db.query("CALL 프로시저이름(?, ?,@변수명); SELECT @변수명", [
        var1, 
        var2], 
      function(err, result) {
        if (err) {
            console.log(err);
        }
        else {
          for (var i = 0; i < result.length; i++) {
            console.log(result[i]); // 여기에 전달받은 결과가 표시됨 @변수명으로...
          };
        }
      });
  });


*/


/* 스케쥴러 date로 생성하기
var schedule = require('node-schedule');
var date = new Date(2014, 9, 18, 9, 30, 0);

var j = schedule.scheduleJob(data, function(){
    console.log('....');
});

*/

/* rule로 관리하는 스케쥴

var schedule = require('node-schedule');
var rule = new schedule.RecurrenceRule();
rule.dayOfWeek = [0, new schedule.Range(4,6)];
rule.hour = 13;
rule.minute = 0;

var j = schedule.scheduleJob(rule, function(){
      console.log('...');
});
*/


/* 크론스타일로 생성하기

var schedule = require('node-schedule');

var j = schedule.scheduleJob('45 * * * *', function(){

});

*    *    *    *    *    *
┬    ┬    ┬    ┬    ┬    ┬
│    │    │    │    │    |
│    │    │    │    │    └ day of week (0 - 7) (0 or 7 is Sun)
│    │    │    │    └───── month (1 - 12)
│    │    │    └────────── day of month (1 - 31)
│    │    └─────────────── hour (0 - 23)
│    └──────────────────── minute (0 - 59)
└───────────────────────── second (0 - 59, OPTIONAL)

*/
