var db_connection =module.exports = {
   
    host    :'us-cdbr-sl-dfw-01.cleardb.net',
    port : '3306',
    user : 'b59613dc281c8d',
    password : 'b6e67cbc',
    database:'ibmx_bb82935ca1201bc',
    multipleStatements : true

}

