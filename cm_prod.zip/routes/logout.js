var express = require('express');
var router = express.Router();

/* GET home page. */

//get으로 처리하는 구문

router.get('/', function(req, res, next) {
  
    
  if(req.session.email){

    req.session.destroy(function(err){
                
    if(err){
        console.log(err);
    }

    else{
        res.redirect('/');
                    
    }
      
    });
      
    }
    
    else{
        
        res.redirect('/');
    
    }

});



//post으로 처리하는 구문

router.post('/', function(req, res, next) {

  if(req.session.email){

    req.session.destroy(function(err){
                
    if(err){
        console.log(err);
    }

    else{
        res.redirect('/');
                    
    }
      
    });
      
    }
    
    else{
        
        res.redirect('/');
    
    }

});


module.exports = router;
