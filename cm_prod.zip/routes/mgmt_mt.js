var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');


//mt_main 호출

    //GET으로 호출

router.get('/mt_main', function(req, res, next) {
     
     
      if(req.session.email){
         
        var session =req.session;
          
       if(req.body.mt_number>=0){
        
        session.mt_number = req.body.mt_number;  
        
        }
              
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number
          
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
        var data =new Array();
        
        connection.query(

        'SELECT MT_NAME, DATE_FORMAT(MT_CREATE_DT,"%Y-%m-%d") AS MT_CREATE_DT, MT_CM_NAME,MT_CM_BANKNAME,MT_CM_BANKACCOUNT,MT_PAYMENT_TYPE,MT_PAYMENT_DATE FROM MEETING_INFO WHERE MT_NAME=(SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+"LIMIT "+mt_number+",1)",function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
        session.mt_name=rows[0].MT_NAME;
        
    
        var mt_name = rows[0].MT_NAME;
        var mt_create_dt = rows[0].MT_CREATE_DT;
        var mt_cm_name = rows[0].MT_CM_NAME;
        var mt_cm_bankname = rows[0].MT_CM_BANKNAME;
        var mt_cm_bankaccount = encryption.AES256Decrypt(rows[0].MT_CM_BANKACCOUNT);
        var mt_payment_type = rows[0].MT_PAYMENT_TYPE;
        var mt_payment_date = rows[0].MT_PAYMENT_DATE;
            
        

        connection.query(

        'SELECT COUNT(MT_NAME) AS MEMB_COUNT FROM MEETING_MEMB WHERE MT_NAME='+mysql.escape(mt_name)+' GROUP BY MT_NAME',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
             
        if(rows.length>0){
            
            var mt_memb_count = rows[0].MEMB_COUNT;       
        }
            
        else{
            
            var mt_memb_count = 0 ;     
        
        }    
           
       connection.query(

        'SELECT MT_PAYMENT_GROUP, MT_PAYMENT_AMOUNT FROM PAYMENT_SETTING WHERE MT_NAME='+mysql.escape(mt_name)+'AND USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
            
        if(rows[0].MT_PAYMENT_GROUP==null){
        
       
            res.render('mt_main', 


            { mt_name: mt_name, mt_create_dt: mt_create_dt, mt_cm_name: mt_cm_name, mt_cm_bankname: mt_cm_bankname, mt_cm_bankaccount: mt_cm_bankaccount, mt_payment_type : mt_payment_type, mt_payment_date : mt_payment_date, mt_memb_count : mt_memb_count , mt_payment_group_number : 0, mt_payment_group_list : 0, mt_number : mt_number, email: req.session.email
            });
  
            connection.end(); 
        }
            
        else{
            
            
           for(i=0;i<rows.length;i++){
            
            data.push(rows[i].MT_PAYMENT_GROUP);
            data.push(rows[i].MT_PAYMENT_AMOUNT);     
            
           }
            
            res.render('mt_main', 


            { mt_name: mt_name, mt_create_dt: mt_create_dt, mt_cm_name: mt_cm_name, mt_cm_bankname: mt_cm_bankname, mt_cm_bankaccount: mt_cm_bankaccount, mt_payment_type : mt_payment_type, mt_payment_date : mt_payment_date, mt_memb_count : mt_memb_count , mt_payment_group_number : rows.length, mt_payment_group_list : data ,mt_number : mt_number, email: req.session.email
            });
            
            connection.end();   
            
        }
    
    });  
          
    });
    });
              
  
    }
    
    else{
        
        res.redirect('/');    
        
    }              
});


               
               
    //POST로 호출

router.post('/mt_main', function(req, res, next) {
      
        
        if(req.session.email){
        
        var session =req.session;
            
        if(req.body.mt_number>=0){
        
        session.mt_number = req.body.mt_number;  
        
        }
             
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number
          
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
        var data =new Array();
        
        connection.query(

        'SELECT MT_NAME, DATE_FORMAT(MT_CREATE_DT,"%Y-%m-%d") AS MT_CREATE_DT, MT_CM_NAME,MT_CM_BANKNAME,MT_CM_BANKACCOUNT,MT_PAYMENT_TYPE,MT_PAYMENT_DATE FROM MEETING_INFO WHERE MT_NAME=(SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+"LIMIT "+mt_number+",1)",function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
        session.mt_name=rows[0].MT_NAME;
        
    
        var mt_name = rows[0].MT_NAME;
        var mt_create_dt = rows[0].MT_CREATE_DT;
        var mt_cm_name = rows[0].MT_CM_NAME;
        var mt_cm_bankname = rows[0].MT_CM_BANKNAME;
        var mt_cm_bankaccount = encryption.AES256Decrypt(rows[0].MT_CM_BANKACCOUNT);
        var mt_payment_type = rows[0].MT_PAYMENT_TYPE;
        var mt_payment_date = rows[0].MT_PAYMENT_DATE;
            
        

        connection.query(

        'SELECT COUNT(MT_NAME) AS MEMB_COUNT FROM MEETING_MEMB WHERE MT_NAME='+mysql.escape(mt_name)+' GROUP BY MT_NAME',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
             
        if(rows.length>0){
            
            var mt_memb_count = rows[0].MEMB_COUNT;       
        }
            
        else{
            
            var mt_memb_count = 0 ;     
        
        }    
           
       connection.query(

        'SELECT MT_PAYMENT_GROUP, MT_PAYMENT_AMOUNT FROM PAYMENT_SETTING WHERE MT_NAME='+mysql.escape(mt_name)+'AND USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
            
        if(rows[0].MT_PAYMENT_GROUP==null){
        
       
            res.render('mt_main', 


            { mt_name: mt_name, mt_create_dt: mt_create_dt, mt_cm_name: mt_cm_name, mt_cm_bankname: mt_cm_bankname, mt_cm_bankaccount: mt_cm_bankaccount, mt_payment_type : mt_payment_type, mt_payment_date : mt_payment_date, mt_memb_count : mt_memb_count , mt_payment_group_number : 0, mt_payment_group_list : 0, mt_number : mt_number, email: req.session.email
            });
  
            connection.end(); 
        }
            
        else{
            
            
           for(i=0;i<rows.length;i++){
            
            data.push(rows[i].MT_PAYMENT_GROUP);
            data.push(rows[i].MT_PAYMENT_AMOUNT);     
            
           }
            
            res.render('mt_main', 


            { mt_name: mt_name, mt_create_dt: mt_create_dt, mt_cm_name: mt_cm_name, mt_cm_bankname: mt_cm_bankname, mt_cm_bankaccount: mt_cm_bankaccount, mt_payment_type : mt_payment_type, mt_payment_date : mt_payment_date, mt_memb_count : mt_memb_count , mt_payment_group_number : rows.length, mt_payment_group_list : data ,mt_number : mt_number, email: req.session.email
            });
            
            connection.end();   
            
        }
    
    });  
          
    });
    });
              
  
    }
    
    else{
        
        res.redirect('/');    
        
    }              
});


router.get('/mt_revenue', function(req, res, next) {
     
   
        
    if(req.session.email){
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
         
        var membData =new Array(); 
        var eventData =new Array();
        var revenueData= new Array();
        
        
        
        connection.query(

        'SELECT MT_NAME,MT_PAYMENT_TYPE,MT_PAYMENT_DATE,DATE_FORMAT(CURDATE(),"%Y-%m-%d") AS NOW FROM MEETING_INFO WHERE MT_NAME='+mt_name,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
            
        var mt_payment_date = rows[0].MT_PAYMENT_DATE;
        var mt_payment_type= rows[0].MT_PAYMENT_TYPE;
        var now =rows[0].NOW
          
        connection.query(    
        
        
        'SELECT (SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END )) AS CURRENT_RESULT,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND YEAR(MT_REVENUE_DATE) <= YEAR(NOW()) AND MONTH(MT_REVENUE_DATE)<MONTH(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND YEAR(MT_REVENUE_DATE) <= YEAR(NOW()) AND MONTH(MT_REVENUE_DATE)<MONTH(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END )) AS PREVIOUS_RESULT,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) AS THIS_MONTH_PROFIT_SUM,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END ) AS THIS_MONTH_EXPENSE_SUM,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) AS MONTH_PROFIT_SEARCH,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END ) AS MONTH_EXPENSE_SEARCH FROM MEETING_REVENUE',function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
            
        revenueData.push(rows[0].CURRENT_RESULT);
        revenueData.push(rows[0].PREVIOUS_RESULT);
        revenueData.push(rows[0].THIS_MONTH_PROFIT_SUM);
        revenueData.push(rows[0].THIS_MONTH_EXPENSE_SUM);
        revenueData.push(rows[0].MONTH_PROFIT_SEARCH);
        revenueData.push(rows[0].MONTH_EXPENSE_SEARCH);
         
             
        connection.query(

        'SELECT MT_PROFIT_YN,MT_MEMB_NUMBER,MT_PROFIT_DETAIL,MT_PROFIT,MT_PROFIT_ACTUAL, DATE_FORMAT(MT_REVENUE_DATE,"%Y-%m-%d") AS MT_REVENUE_DATE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+'AND MT_REVENUE_DISTINCT="P" AND YEAR(MT_REVENUE_DATE) = YEAR(CURDATE()) AND MONTH(MT_REVENUE_DATE)=MONTH(CURDATE()) ORDER BY MT_MEMB_NUMBER',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
         
        for(i=0;i<rows.length;i++){
             
        membData.push(rows[i].MT_PROFIT_YN);                    
        membData.push(rows[i].MT_MEMB_NUMBER);
        membData.push(rows[i].MT_PROFIT_DETAIL);
        membData.push(rows[i].MT_PROFIT);  
        membData.push(rows[i].MT_PROFIT_ACTUAL);  
        membData.push(rows[i].MT_REVENUE_DATE);   
         
        }
  
        connection.query(

        'SELECT MT_EVENT_NUMBER,MT_EXPENSE_NAME,MT_EXPENSE_ROUND,MT_EXPENSE_LOCATION,MT_EXPENSE, DATE_FORMAT(MT_REVENUE_DATE,"%Y-%m-%d") AS MT_REVENUE_DATE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+'AND MT_REVENUE_DISTINCT="E" AND YEAR(MT_REVENUE_DATE) = YEAR(CURDATE()) AND MONTH(MT_REVENUE_DATE)=MONTH(CURDATE()) ',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
                
        for(i=0;i<rows.length;i++){
                      
        eventData.push(rows[i].MT_EVENT_NUMBER);
        eventData.push(rows[i].MT_EXPENSE_NAME);
        eventData.push(rows[i].MT_EXPENSE_ROUND);  
        eventData.push(rows[i].MT_EXPENSE_LOCATION);
        eventData.push(rows[i].MT_EXPENSE); 
        eventData.push(rows[i].MT_REVENUE_DATE);       
         
        }
             
            
        res.render('mt_revenue', { mt_name : mt_name, mt_payment_type : mt_payment_type, mt_payment_date : mt_payment_date,email : req.session.email ,mt_number : mt_number,now: now, memb_data : membData,event_data : eventData, revenue_data: revenueData});
            
        connection.end();  
            
        });
            
    });
  
});
});
}
    
    else{
        
        
        res.redirect('/');    
     }

});



router.post('/mt_revenue', function(req, res, next) {
     
    if(req.session.email){
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
         
        var membData =new Array(); 
        var eventData =new Array();
        var revenueData= new Array();
        
        
        
        connection.query(

        'SELECT MT_NAME,MT_PAYMENT_TYPE,MT_PAYMENT_DATE,DATE_FORMAT(CURDATE(),"%Y-%m-%d") AS NOW FROM MEETING_INFO WHERE MT_NAME='+mt_name,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
            
        var mt_payment_date = rows[0].MT_PAYMENT_DATE;
        var mt_payment_type= rows[0].MT_PAYMENT_TYPE;
        var now =rows[0].NOW
          
        connection.query(    
        
        
        'SELECT (SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END )) AS CURRENT_RESULT,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND YEAR(MT_REVENUE_DATE) <= YEAR(NOW()) AND MONTH(MT_REVENUE_DATE)<MONTH(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND YEAR(MT_REVENUE_DATE) <= YEAR(NOW()) AND MONTH(MT_REVENUE_DATE)<MONTH(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END )) AS PREVIOUS_RESULT,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) AS THIS_MONTH_PROFIT_SUM,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END ) AS THIS_MONTH_EXPENSE_SUM,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) AS MONTH_PROFIT_SEARCH,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND MONTH(MT_REVENUE_DATE)=MONTH(NOW()) AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END ) AS MONTH_EXPENSE_SEARCH FROM MEETING_REVENUE',function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
            
        revenueData.push(rows[0].CURRENT_RESULT);
        revenueData.push(rows[0].PREVIOUS_RESULT);
        revenueData.push(rows[0].THIS_MONTH_PROFIT_SUM);
        revenueData.push(rows[0].THIS_MONTH_EXPENSE_SUM);
        revenueData.push(rows[0].MONTH_PROFIT_SEARCH);
        revenueData.push(rows[0].MONTH_EXPENSE_SEARCH);
         
             
        connection.query(

        'SELECT MT_PROFIT_YN,MT_MEMB_NUMBER,MT_PROFIT_DETAIL,MT_PROFIT,MT_PROFIT_ACTUAL, DATE_FORMAT(MT_REVENUE_DATE,"%Y-%m-%d") AS MT_REVENUE_DATE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+'AND MT_REVENUE_DISTINCT="P" AND YEAR(MT_REVENUE_DATE) = YEAR(CURDATE()) AND MONTH(MT_REVENUE_DATE)=MONTH(CURDATE()) ORDER BY MT_MEMB_NUMBER',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
         
        for(i=0;i<rows.length;i++){
             
        membData.push(rows[i].MT_PROFIT_YN);                    
        membData.push(rows[i].MT_MEMB_NUMBER);
        membData.push(rows[i].MT_PROFIT_DETAIL);
        membData.push(rows[i].MT_PROFIT);  
        membData.push(rows[i].MT_PROFIT_ACTUAL);  
        membData.push(rows[i].MT_REVENUE_DATE);   
         
        }
  
        connection.query(

        'SELECT MT_EVENT_NUMBER,MT_EXPENSE_NAME,MT_EXPENSE_ROUND,MT_EXPENSE_LOCATION,MT_EXPENSE, DATE_FORMAT(MT_REVENUE_DATE,"%Y-%m-%d") AS MT_REVENUE_DATE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+'AND MT_REVENUE_DISTINCT="E" AND YEAR(MT_REVENUE_DATE) = YEAR(CURDATE()) AND MONTH(MT_REVENUE_DATE)=MONTH(CURDATE()) ',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
                
        for(i=0;i<rows.length;i++){
                      
        eventData.push(rows[i].MT_EVENT_NUMBER);
        eventData.push(rows[i].MT_EXPENSE_NAME);
        eventData.push(rows[i].MT_EXPENSE_ROUND);  
        eventData.push(rows[i].MT_EXPENSE_LOCATION);
        eventData.push(rows[i].MT_EXPENSE); 
        eventData.push(rows[i].MT_REVENUE_DATE);       
         
        }
             
            
        res.render('mt_revenue', { mt_name : mt_name, mt_payment_type : mt_payment_type, mt_payment_date : mt_payment_date,email : req.session.email ,mt_number : mt_number,now: now, memb_data : membData,event_data : eventData, revenue_data: revenueData});
            
        connection.end();  
            
        });
            
    });
  
});
});
}
    
    else{
        
        
        res.redirect('/');    
     }

});


router.get('/mt_event', function(req, res, next) {
         
     if(req.session.email){
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
        var data =new Array();
        var data_past=new Array();
        
            
        connection.query(
            
        'SELECT MT_EVENT_NUMBER, MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d") AS MT_EVENT_DATE_FULL,MT_EVENT_ROUND,MT_EVENT_TIME,MT_EVENT_LOCATION,MT_EVENT_URL FROM MEETING_EVENT WHERE MT_NAME='+mt_name+" AND USER_EMAIL="+user_email+" AND MT_EVENT_DATE >= NOW() ORDER BY MT_EVENT_DATE",function(err,rows,fields){           
        
        if (err) {
            console.error(err);
            throw err;
        }
                 
                 
        for(i=0;i<rows.length;i++){
                      
            data.push(rows[i].MT_EVENT_NUMBER);
            data.push(rows[i].MT_EVENT_NAME);    
            data.push(rows[i].MT_EVENT_ROUND);  
            data.push(rows[i].MT_EVENT_DATE_FULL);
            data.push(rows[i].MT_EVENT_TIME);     
            data.push(rows[i].MT_EVENT_LOCATION);
            data.push(rows[i].MT_EVENT_URL);
                
        } 
            
        
         connection.query(
            
        'SELECT MT_EVENT_NUMBER, MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d") AS MT_EVENT_DATE_FULL,MT_EVENT_ROUND,MT_EVENT_TIME,MT_EVENT_LOCATION,MT_EVENT_URL FROM MEETING_EVENT WHERE MT_NAME='+mt_name+" AND USER_EMAIL="+user_email+" AND MT_EVENT_DATE < NOW() ORDER BY MT_EVENT_DATE",function(err,rows,fields){           
        
        if (err) {
            console.error(err);
            throw err;
        }
                 
                 
        for(i=0;i<rows.length;i++){
                      
            data_past.push(rows[i].MT_EVENT_NUMBER);
            data_past.push(rows[i].MT_EVENT_NAME);    
            data_past.push(rows[i].MT_EVENT_ROUND);  
            data_past.push(rows[i].MT_EVENT_DATE_FULL);
            data_past.push(rows[i].MT_EVENT_TIME);     
            data_past.push(rows[i].MT_EVENT_LOCATION);
            data_past.push(rows[i].MT_EVENT_URL);
                
        } 
           
                 
        connection.query(
            
        'SELECT COUNT(MT_EVENT_NAME) AS MT_EVENT_NUMBER FROM MEETING_EVENT WHERE MT_NAME='+mt_name+' AND USER_EMAIL='+user_email,function(err,rows,fields){ 
              
        if (err) {
            console.error(err);
            throw err;
        }
                 
             
        var mt_event_number = rows[0].MT_EVENT_NUMBER;
                 
        res.render('mt_event', {mt_name : mt_name, email : req.session.email ,mt_number : mt_number, mt_event_data : data , mt_event_data_past : data_past, mt_event_number : mt_event_number  });
        
        connection.end();
    });     
                              
    });
    });
            

        
        
     }
    
  
    else{
        
        res.redirect('/');    
     }

});





  //POST로 호출

router.post('/mt_event', function(req, res, next) {
     
      if(req.session.email){
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
        var data =new Array();
        var data_past=new Array();
        
            
        connection.query(
            
        'SELECT MT_EVENT_NUMBER, MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d") AS MT_EVENT_DATE_FULL,MT_EVENT_ROUND,MT_EVENT_TIME,MT_EVENT_LOCATION,MT_EVENT_URL FROM MEETING_EVENT WHERE MT_NAME='+mt_name+" AND USER_EMAIL="+user_email+" AND MT_EVENT_DATE >= NOW() ORDER BY MT_EVENT_DATE",function(err,rows,fields){           
        
        if (err) {
            console.error(err);
            throw err;
        }
                 
                 
        for(i=0;i<rows.length;i++){
                      
            data.push(rows[i].MT_EVENT_NUMBER);
            data.push(rows[i].MT_EVENT_NAME);    
            data.push(rows[i].MT_EVENT_ROUND);  
            data.push(rows[i].MT_EVENT_DATE_FULL);
            data.push(rows[i].MT_EVENT_TIME);     
            data.push(rows[i].MT_EVENT_LOCATION);
            data.push(rows[i].MT_EVENT_URL);
                
        } 
            
        
         connection.query(
            
        'SELECT MT_EVENT_NUMBER, MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d") AS MT_EVENT_DATE_FULL,MT_EVENT_ROUND,MT_EVENT_TIME,MT_EVENT_LOCATION,MT_EVENT_URL FROM MEETING_EVENT WHERE MT_NAME='+mt_name+" AND USER_EMAIL="+user_email+" AND MT_EVENT_DATE < NOW() ORDER BY MT_EVENT_DATE",function(err,rows,fields){           
        
        if (err) {
            console.error(err);
            throw err;
        }
                 
                 
        for(i=0;i<rows.length;i++){
                      
            data_past.push(rows[i].MT_EVENT_NUMBER);
            data_past.push(rows[i].MT_EVENT_NAME);    
            data_past.push(rows[i].MT_EVENT_ROUND);  
            data_past.push(rows[i].MT_EVENT_DATE_FULL);
            data_past.push(rows[i].MT_EVENT_TIME);     
            data_past.push(rows[i].MT_EVENT_LOCATION);
            data_past.push(rows[i].MT_EVENT_URL);
                
        } 
           
                 
        connection.query(
            
        'SELECT COUNT(MT_EVENT_NAME) AS MT_EVENT_NUMBER FROM MEETING_EVENT WHERE MT_NAME='+mt_name+' AND USER_EMAIL='+user_email,function(err,rows,fields){ 
              
        if (err) {
            console.error(err);
            throw err;
        }
                 
             
        var mt_event_number = rows[0].MT_EVENT_NUMBER;
                 
        res.render('mt_event', {mt_name : mt_name, email : req.session.email ,mt_number : mt_number, mt_event_data : data , mt_event_data_past : data_past, mt_event_number : mt_event_number  });
        
        connection.end();
    });     
                              
    });
    });
            

        
        
     }
    
  
    else{
        
        res.redirect('/');    
     }

});




router.get('/mt_member', function(req, res, next) {
     
        
     if(req.session.email){
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
        var data =new Array();
        var data2 =new Array(); 
       
            
        connection.query(
             
        'SELECT MT_MEMB_NUMBER,MT_MEMB_NAME,MT_MEMB_PHONE,MT_PAYMENT_GROUP FROM MEETING_MEMB WHERE MT_NAME='+mt_name+' AND USER_EMAIL='+user_email,function(err,rows,fields){     
            
        if (err) {
                console.error(err);
                throw err;
        }
                          
        for(i=0;i<rows.length;i++){
            
            data2.push(rows[i].MT_MEMB_NUMBER);
            data2.push(rows[i].MT_MEMB_NAME);
            data2.push(rows[i].MT_MEMB_PHONE); data2.push(rows[i].MT_PAYMENT_GROUP);
                    
        }         
        
        var mt_memb_count = rows.length; 
        
        connection.query(
            
        'SELECT PAYMENT_SETTING.MT_PAYMENT_GROUP,PAYMENT_SETTING.MT_PAYMENT_AMOUNT,COUNT(MEETING_MEMB.MT_PAYMENT_GROUP) AS MT_PAYMENT_GROUP_NUMBER FROM MEETING_MEMB RIGHT JOIN PAYMENT_SETTING ON MEETING_MEMB.USER_EMAIL = PAYMENT_SETTING.USER_EMAIL AND MEETING_MEMB.MT_NAME = PAYMENT_SETTING.MT_NAME AND MEETING_MEMB.MT_PAYMENT_GROUP = PAYMENT_SETTING.MT_PAYMENT_GROUP'+' WHERE PAYMENT_SETTING.MT_NAME='+mt_name+' GROUP BY MT_PAYMENT_GROUP',function(err,rows,fields){
                  
        if (err) {
                console.error(err);
                throw err;
        }
            
                     
        if(rows[0].MT_PAYMENT_GROUP==null){
                
        res.render('mt_member', 

        { mt_name: mt_name, mt_payment_group_list: null,mt_memb_data: data, mt_memb_count: mt_memb_count, mt_number : mt_number, email: req.session.email
        });

        connection.end();    
        
        }   
            
        else{
                
        for(i=0;i<rows.length;i++){
                
            data.push(rows[i].MT_PAYMENT_GROUP); 
            data.push(rows[i].MT_PAYMENT_AMOUNT);
            data.push(rows[i].MT_PAYMENT_GROUP_NUMBER);    
        }
                
        res.render('mt_member', 

        { mt_name: mt_name, mt_payment_group_list : data, mt_memb_data: data2, mt_memb_count: mt_memb_count, mt_number : mt_number, email: req.session.email
        });
         
        connection.end();   
            
        }
                 
          
    });         
    });
              
}
              

else{
    
    res.redirect('/');    
    }

});


router.post('/mt_member', function(req, res, next) {
     
     if(req.session.email){
        
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
        var data =new Array();
        var data2 =new Array(); 
       
            
        connection.query(
             
        'SELECT MT_MEMB_NUMBER,MT_MEMB_NAME,MT_MEMB_PHONE,MT_PAYMENT_GROUP FROM MEETING_MEMB WHERE MT_NAME='+mt_name+' AND USER_EMAIL='+user_email,function(err,rows,fields){     
            
        if (err) {
                console.error(err);
                throw err;
        }
                          
        for(i=0;i<rows.length;i++){
            
            data2.push(rows[i].MT_MEMB_NUMBER);
            data2.push(rows[i].MT_MEMB_NAME);
            data2.push(rows[i].MT_MEMB_PHONE); data2.push(rows[i].MT_PAYMENT_GROUP);
                    
        }         
        
        var mt_memb_count = rows.length; 
        
        connection.query(
            
        'SELECT PAYMENT_SETTING.MT_PAYMENT_GROUP,PAYMENT_SETTING.MT_PAYMENT_AMOUNT,COUNT(MEETING_MEMB.MT_PAYMENT_GROUP) AS MT_PAYMENT_GROUP_NUMBER FROM MEETING_MEMB RIGHT JOIN PAYMENT_SETTING ON MEETING_MEMB.USER_EMAIL = PAYMENT_SETTING.USER_EMAIL AND MEETING_MEMB.MT_NAME = PAYMENT_SETTING.MT_NAME AND MEETING_MEMB.MT_PAYMENT_GROUP = PAYMENT_SETTING.MT_PAYMENT_GROUP'+' WHERE PAYMENT_SETTING.MT_NAME='+mt_name+' GROUP BY MT_PAYMENT_GROUP ',function(err,rows,fields){
                  
        if (err) {
                console.error(err);
                throw err;
        }
            
                     
        if(rows[0].MT_PAYMENT_GROUP==null){
                
        res.render('mt_member', 

        { mt_name: mt_name, mt_payment_group_list: null,mt_memb_data: data, mt_memb_count: mt_memb_count, mt_number : mt_number, email: req.session.email
        });

        connection.end();    
        
        }   
            
        else{
                
        for(i=0;i<rows.length;i++){
                
            data.push(rows[i].MT_PAYMENT_GROUP); 
            data.push(rows[i].MT_PAYMENT_AMOUNT);
            data.push(rows[i].MT_PAYMENT_GROUP_NUMBER);    
        }
                
        res.render('mt_member', 

        { mt_name: mt_name, mt_payment_group_list : data, mt_memb_data: data2, mt_memb_count: mt_memb_count, mt_number : mt_number, email: req.session.email
        });
         
        connection.end();   
            
        }
                 
          
    });         
    });
              
}
              

else{
    
    res.redirect('/');    
    }

});


//모임삭제하는 POST 방식



router.post('/delete', function(req, res, next) {
      
          
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number = req.session.mt_number;
        var mt_name= mysql.escape(req.session.mt_name);
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
    
        
         var query = "";
        
        query += 'DELETE FROM MEETING_INFO WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+';'
                
        query += 'DELETE FROM MEETING_MEMB WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+';'
    
        query += 'DELETE FROM MEETING_EVENT WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+';'
    
        query += 'DELETE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+';'
    
        query += 'DELETE FROM PAYMENT_SETTING WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+';'
      
        connection.query( query, function(err,rows,fields){ 
        
    
            if (err) {
                console.error(err);
                throw err;
                res.json({result : 'false'});
            }
            
            res.json({result : 'success'});  
            connection.end();
      
       });
         
});
    
 
module.exports = router;

