var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');
var db_connection= require('../routes/db_connection');
var async = require('async');

router.post('/plus', function(req, res, next) {
    
    var user_email = mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number = req.session.mt_number;
    var connection= mysql.createConnection(db_connection);
    var mt_name = mysql.escape(req.session.mt_name);

    var value1 = new Array();
    var value2= new Array();
   
    console.log(req.body);

    for(var key in req.body) {
        value1.push(key);
        }

    console.log(value1);

    for(var key in req.body) {
        value2.push(req.body[key]);
        }

    console.log(value2);
    
            
    connection.query(

    'SELECT MAX(MT_MEMB_NUMBER) AS MAX FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name ,function(err,rows,fields){

        if (err) {
                console.log(err);
                throw err;         
        }

        console.log(rows[0].MAX);

    if(Number(rows[0].MAX)>=100000000){
        
    var maxNumber = Number(rows[0].MAX)  
      
    }
    
    else{
        
    var maxNumber = 100000000;
        
    }
      
    for(i=0;i<value1.length;i++){
        
    if(value1[i].substring(0,7)=="mt_memb"){
        
         
        
        if(value2[i][2]=="on"){
       
        connection.query(

        'UPDATE MEETING_REVENUE SET MT_PROFIT_ACTUAL='+(value2[i][1])+' ,MT_PROFIT_YN="Y" WHERE MT_REVENUE_DISTINCT="P" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND MT_MEMB_NUMBER='+value1[i].substring(7,20),

        function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                };

        });
        }
        
        else{
      
            
        connection.query(

        'UPDATE MEETING_REVENUE SET MT_PROFIT_YN="N" WHERE MT_REVENUE_DISTINCT="P" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND MT_MEMB_NUMBER='+value1[i].substring(7,20),

        function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                };

        });    
            
            
            
        }
    }

    else{
      
    
    
    if(value2[i][2]=="on"){    
        
    
        console.log('여기로 들어옴4');
        maxNumber= maxNumber+1;  
        connection.query(

        'INSERT MEETING_REVENUE(USER_EMAIL,MT_NAME,MT_PROFIT,MT_PROFIT_ACTUAL,MT_PROFIT_DETAIL,MT_PROFIT_YN,MT_MEMB_NUMBER,MT_REVENUE_DATE,MT_REVENUE_DISTINCT) VALUES('
            
        +user_email+','+mt_name+',0,'+mysql.escape(value2[i][1])+','+mysql.escape(value2[i][0])+',"Y",'+maxNumber+','+mysql.escape(value2[i][3])+',"P")',
        //저 기타쪽에들어가는 날짜 손봐줘야 함 그리고 NUMBER도 손봐야함
                                                           
        function(err,rows,fields){
            
            
           if (err) {
                console.log(err);
                throw err;
                }
            
          
               
        });
    
    }
    
    }

 
    }
    
    });
   
    res.json({result : 'success'});
    //connection.end();
});
                
    
    
            
       
router.post('/minus', function(req, res, next) {
    
    var user_email = mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number = req.session.mt_number;
    var connection= mysql.createConnection(db_connection);
    var mt_name = mysql.escape(req.session.mt_name);
    
    var value1 = new Array();
    var value2= new Array();
   

    for(var key in req.body) {
        value1.push(key);
        }

    console.log(value1);

    for(var key in req.body) {
        value2.push(req.body[key]);
        }

    console.log(value2);
    
    
            
    connection.query(

    'SELECT MAX(MT_EVENT_NUMBER) AS MAX FROM MEETING_EVENT WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name 

    ,function(err,rows,fields){

        if (err) {
                console.log(err);
                 throw err;         
        }
                
             
        if(Number(rows[0].MAX)>=100000000){
        
        var maxNumber = Number(rows[0].MAX)  
      
        }
    
        else{
        
        var maxNumber = 100000000;
        
        }
            
    
   
    for(i=0;i<value1.length;i++){
    
    if(value1[i].substring(0,8)=="mt_event"){
        
        connection.query(

        'UPDATE MEETING_REVENUE SET MT_EXPENSE='+(value2[i][3])+' ,MT_EXPENSE_YN="Y" WHERE MT_EVENT_NUMBER='+value1[i].substring(8,20),

        function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                };

        });
    }
        
    else{
        
        var maxNumber= maxNumber+1;
        
        connection.query(

        'INSERT MEETING_REVENUE(USER_EMAIL,MT_NAME,MT_EXPENSE_NAME,MT_EXPENSE_ROUND,MT_EXPENSE_LOCATION,MT_EXPENSE,MT_EVENT_NUMBER,MT_EXPENSE_YN,MT_REVENUE_DISTINCT,MT_REVENUE_DATE) VALUES('
            
        +user_email+','+mt_name+','+mysql.escape(value2[i][0])+','+mysql.escape(value2[i][1])+','+mysql.escape(value2[i][2])+','+(value2[i][3])+','+maxNumber+',"Y","E",'+mysql.escape(value2[i][4])+')',
       
                                                           
        function(err,rows,fields){
            
            
           if (err) {
                console.log(err);
                throw err;
                }
            
        
        });
    
    }
        
    }
            });
    res.json({result : 'success'});
    //connection.end();
});
   
         
    
router.post('/view', function(req, res, next) {
    
    var user_email = mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number = req.session.mt_number;
    var mt_name = mysql.escape(req.session.mt_name);
   
    
    var connection= mysql.createConnection(db_connection);
    var revenueData=[];
    var membData=[];
    var eventData=[];
    
    var date = req.body.date+"-01";
    console.log(date);
    console.log(req.body);
    
    connection.query(
    
        
    'SELECT SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND MONTH(DATE_ADD('+mysql.escape(date)+', INTERVAL '+req.body.change+' MONTH))=MONTH(MT_REVENUE_DATE) AND YEAR('+mysql.escape(date)+')=YEAR(MT_REVENUE_DATE) AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' THEN MT_PROFIT_ACTUAL ELSE 0 END ) AS MONTH_PROFIT_SEARCH,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MONTH(DATE_ADD('+mysql.escape(date)+', INTERVAL '+req.body.change+' MONTH))=MONTH(MT_REVENUE_DATE) AND YEAR('+mysql.escape(date)+')=YEAR(MT_REVENUE_DATE) AND USER_EMAIL='+user_email+'AND MT_NAME='+mt_name+' THEN MT_EXPENSE ELSE 0 END ) AS MONTH_EXPENSE_SEARCH ,DATE_ADD('+mysql.escape(date)+', INTERVAL '+req.body.change+' MONTH) AS NOW FROM MEETING_REVENUE',function(err,rows,fields){

    if (err) {
        console.error(err);
        throw err;
    }
            
    revenueData.push(rows[0].MONTH_PROFIT_SEARCH);
    revenueData.push(rows[0].MONTH_EXPENSE_SEARCH);
    var  now=rows[0].NOW;
         
             
    connection.query(

    'SELECT MT_PROFIT_YN,MT_MEMB_NUMBER,MT_PROFIT_DETAIL,MT_PROFIT,MT_PROFIT_ACTUAL ,DATE_FORMAT(MT_REVENUE_DATE,"%Y-%m-%d") AS MT_REVENUE_DATE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+'AND MONTH(DATE_ADD('+mysql.escape(date)+', INTERVAL '+req.body.change+' MONTH))=MONTH(MT_REVENUE_DATE) AND YEAR('+mysql.escape(date)+')=YEAR(MT_REVENUE_DATE) AND MT_REVENUE_DISTINCT="P" ',function(err,rows,fields){

    if (err) {
        console.error(err);
        throw err;
    }
         
            
    for(i=0;i<rows.length;i++){
             
        membData.push(rows[i].MT_PROFIT_YN);                    
        membData.push(rows[i].MT_MEMB_NUMBER);
        membData.push(rows[i].MT_PROFIT_DETAIL);
        membData.push(rows[i].MT_PROFIT);  
        membData.push(rows[i].MT_PROFIT_ACTUAL);  
        membData.push(rows[i].MT_REVENUE_DATE); 
         
    }
      
            
    connection.query(

    'SELECT MT_EVENT_NUMBER,MT_EXPENSE_NAME,MT_EXPENSE_ROUND,MT_EXPENSE_LOCATION,MT_EXPENSE ,DATE_FORMAT(MT_REVENUE_DATE,"%Y-%m-%d") AS MT_REVENUE_DATE FROM MEETING_REVENUE WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND MT_REVENUE_DISTINCT="E" AND MONTH(DATE_ADD('+mysql.escape(date)+', INTERVAL '+req.body.change+' MONTH))=MONTH(MT_REVENUE_DATE) AND YEAR('+mysql.escape(date)+')=YEAR(MT_REVENUE_DATE)',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
            
        for(i=0;i<rows.length;i++){
                      
        eventData.push(rows[i].MT_EVENT_NUMBER);
        eventData.push(rows[i].MT_EXPENSE_NAME);
        eventData.push(rows[i].MT_EXPENSE_ROUND);  
        eventData.push(rows[i].MT_EXPENSE_LOCATION);
        eventData.push(rows[i].MT_EXPENSE); 
        eventData.push(rows[i].MT_REVENUE_DATE);    
         
         }
             
        console.log(eventData);    
        
        res.json({result : "success", now: now, memb_data : membData, event_data : eventData, revenue_data: revenueData});
        connection.end();
    });
  
});
});

});



router.post('/delete', function(req, res, next) {
    
    var user_email = mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number = req.session.mt_number;
    var mt_name = mysql.escape(req.session.mt_name);
    var connection= mysql.createConnection(db_connection);
    
    var delete_id = req.body.id;
    var delete_date = req.body.date+'-01';
    
  
    
    if(delete_id.substring(0,7)=="mt_memb"){
      
    connection.query(
    
    'DELETE FROM MEETING_REVENUE WHERE MT_MEMB_NUMBER='+Number(delete_id.substring(7,20))+' AND YEAR(MT_REVENUE_DATE)=YEAR('+mysql.escape(delete_date)+') AND MONTH(MT_REVENUE_DATE)=MONTH('+mysql.escape(delete_date)+') AND MT_NAME='+mt_name+'AND USER_EMAIL='+user_email,function(err,rows,fields){

    if (err) {
        console.error(err);
        throw err;
    }
         
    res.json({result : "success"});
    connection.end();
        
    
    });
    }
    
    else{
    
   
    connection.query(
    
   
        
        
    'DELETE FROM MEETING_REVENUE WHERE MT_EVENT_NUMBER='+Number(delete_id.substring(8,20))+' AND YEAR(MT_REVENUE_DATE)=YEAR('+mysql.escape(delete_date)+') AND MONTH(MT_REVENUE_DATE)=MONTH('+mysql.escape(delete_date)+') AND MT_NAME='+mt_name+'AND USER_EMAIL='+user_email,function(err,rows,fields){

    if (err) {
        console.error(err);
        throw err;
    }
         
    res.json({result : "success"});
    connection.end();
        
    
    });    
        
        
    }
    
    

});

    

            
 
            
module.exports = router;