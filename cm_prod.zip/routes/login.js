var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');

router.post('/', function(req, res, next) {
    
    var session= req.session; 
    
    var user = {'email':req.body.email,
                'pwd':req.body.pwd_type,
                };
    
    
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    var user_email = mysql.escape(encryption.AES256Encrypt(user.email));
    var user_password = mysql.escape(encryption.SHA256Encrypt(user.pwd));
    

    connection.query(
       
    'SELECT * FROM USER WHERE USER_EMAIL='+user_email+'AND USER_PASSWORD='+user_password,function(err,rows,fields){


    if (err) {
            console.error(err);
            throw err;
    }


    if(rows.length==0) {

    res.json({result :"fail"});
    connection.end();
    console.log('RESPONSE TO AJX DUE TO LOGIN FAILURE');

    }


    else {

    console.log(user.email+' AND PASSWORD EXIST');

    session.email = user.email;
    res.json({result :"success"});
    console.log("LOGIN SUCCESS!"); 
    connection.end();    

    }    

});
            
        
        
});

module.exports = router;
