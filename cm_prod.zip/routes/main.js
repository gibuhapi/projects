var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');

    //get으로 처리하는 구문

    router.get('/', function(req, res, next) {
        
     
    if(req.session.email) {
        
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);

        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var data = new Array();
        
       connection.query(

        'SELECT * FROM USER WHERE USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
        
        var name = rows[0].CM_NAME;
        var bankname= rows[0].CM_BANKNAME;
        var bankaccount=encryption.AES256Decrypt(rows[0].CM_BANKACCOUNT); 
     
                
        connection.query(
            
        'SELECT COUNT(MT_NAME) AS MT_NUMBER FROM MEETING_INFO WHERE USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
    
         
        var mt_number = rows[0].MT_NUMBER;
        
                
        connection.query('SELECT MT_NAME,MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d %h:%i %p") AS MT_EVENT_DATE_FULL,MT_EVENT_ROUND FROM MEETING_EVENT WHERE USER_EMAIL='+user_email+' AND MT_EVENT_DATE >= NOW() ORDER BY MT_EVENT_DATE,MT_EVENT_TIME LIMIT 0,5' ,function(err,rows,fields){           
              
        if (err) {
            console.error(err);
            throw err;
         }
         
                    
        for(i=0;i<rows.length;i++){
                
            data.push(rows[i].MT_NAME);     
            data.push(rows[i].MT_EVENT_NAME);    
            data.push(rows[i].MT_EVENT_ROUND);  
            data.push(rows[i].MT_EVENT_DATE_FULL);
        }
            
            
            
        connection.query(

        'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+" LIMIT 0,1",function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
        console.log(rows[0]);
        
        if(!rows[0]){
        
        var mt_name="모임 없음";
            
            
        connection.query(
            
        'SELECT DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -2 MONTH),"%Y-%m") AS P_PREMONTH, DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -1 MONTH),"%Y-%m") AS PREMONTH,DATE_FORMAT(NOW(),"%Y-%m") AS NOW',function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
            
        var mt_revenue_date= new Array();  
        
        mt_revenue_date.push(rows[0].P_PREMONTH);
        mt_revenue_date.push(rows[0].PREMONTH);
        mt_revenue_date.push(rows[0].NOW);        
        
        
            
            
        var mt_name_index=-1;
        var mt_revenue_data=[0,0,0,0,0,0,0,0,0];
       
            
        res.render('main', 
                   
        {'name': name,'email': req.session.email, 'bankname': bankname, 'bankaccount':bankaccount ,'mt_number' : mt_number,mt_event_data : data, mt_name: mt_name, mt_name_index: mt_name_index, mt_revenue_date:mt_revenue_date,mt_revenue_data : mt_revenue_data });
            
              
        
        });
        connection.end();    
        }
        
        else{
            
        var mt_name = mysql.escape(rows[0].MT_NAME);
        
        connection.query(
            
        'SELECT DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -2 MONTH),"%Y-%m") AS P_PREMONTH, DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -1 MONTH),"%Y-%m") AS PREMONTH,DATE_FORMAT(NOW(),"%Y-%m") AS NOW, (SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_EXPENSE ELSE 0 END)) AS P_PREMONTH_PAST, SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS P_PREMONTH_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_EXPENSE ELSE 0 END) AS P_PREMONTH_EXPENSE,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_EXPENSE ELSE 0 END )) AS PREMONTH_PAST, SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS PREMONTH_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_EXPENSE ELSE 0 END ) AS PREMONTH_EXPENSE,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(NOW()) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(NOW()) THEN MT_EXPENSE ELSE 0 END )) AS NOW_PAST,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(NOW()) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS NOW_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(NOW()) THEN MT_EXPENSE ELSE 0 END ) AS NOW_EXPENSE FROM MEETING_REVENUE'       
            
        ,function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
        
        var mt_revenue_data= new Array();
        var mt_revenue_date= new Array();  
         
        var mt_name_index=0;
        
        mt_revenue_date.push(rows[0].P_PREMONTH);
        mt_revenue_date.push(rows[0].PREMONTH);
        mt_revenue_date.push(rows[0].NOW);    
        mt_revenue_data.push(rows[0].P_PREMONTH_PAST);
        mt_revenue_data.push(rows[0].P_PREMONTH_PROFIT);
        mt_revenue_data.push(rows[0].P_PREMONTH_EXPENSE);
        mt_revenue_data.push(rows[0].PREMONTH_PAST);
        mt_revenue_data.push(rows[0].PREMONTH_PROFIT);
        mt_revenue_data.push(rows[0].PREMONTH_EXPENSE);
        mt_revenue_data.push(rows[0].NOW_PAST);
        mt_revenue_data.push(rows[0].NOW_PROFIT);
        mt_revenue_data.push(rows[0].NOW_EXPENSE); 
            
        res.render('main', 
                   
        {'name': name,'email': req.session.email, 'bankname': bankname, 'bankaccount':bankaccount ,'mt_number' : mt_number,mt_event_data : data, mt_name: mt_name, mt_name_index: mt_name_index, mt_revenue_date:mt_revenue_date,mt_revenue_data : mt_revenue_data });
            
        connection.end();        
        
       
        });
    }
            
        });
            
    });
            
    });
    
    
    });        
          
    
    }
        
          
    else{    
        res.redirect('/');
    } 
        
        
});

    //post으로 처리하는 구문

    router.post('/', function(req, res, next) {

      if(req.session.email) {
        
        
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);

        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var data = new Array();
        
       connection.query(

        'SELECT * FROM USER WHERE USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
        
        var name = rows[0].CM_NAME;
        var bankname= rows[0].CM_BANKNAME;
        var bankaccount=encryption.AES256Decrypt(rows[0].CM_BANKACCOUNT); 
     
                
        connection.query(
            
        'SELECT COUNT(MT_NAME) AS MT_NUMBER FROM MEETING_INFO WHERE USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
    
         
        var mt_number = rows[0].MT_NUMBER;
        
                
        connection.query('SELECT MT_NAME,MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d %h:%i %p") AS MT_EVENT_DATE_FULL,MT_EVENT_ROUND FROM MEETING_EVENT WHERE USER_EMAIL='+user_email+' AND MT_EVENT_DATE >= NOW() ORDER BY MT_EVENT_DATE,MT_EVENT_TIME LIMIT 0,5' ,function(err,rows,fields){           
              
        if (err) {
            console.error(err);
            throw err;
         }
         
                    
        for(i=0;i<rows.length;i++){
                
            data.push(rows[i].MT_NAME);     
            data.push(rows[i].MT_EVENT_NAME);    
            data.push(rows[i].MT_EVENT_ROUND);  
            data.push(rows[i].MT_EVENT_DATE_FULL);
        }
            
            
            
        connection.query(

        'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+" LIMIT 0,1",function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
            
        console.log(rows[0]);
        
        if(!rows[0]){
        
        var mt_name="현재 생성된 모임 없음";
            
            
        connection.query(
            
        'SELECT DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -2 MONTH),"%Y-%m") AS P_PREMONTH, DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -1 MONTH),"%Y-%m") AS PREMONTH,DATE_FORMAT(NOW(),"%Y-%m") AS NOW',function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
            
        var mt_revenue_date= new Array();  
        
        mt_revenue_date.push(rows[0].P_PREMONTH);
        mt_revenue_date.push(rows[0].PREMONTH);
        mt_revenue_date.push(rows[0].NOW);        
        
        
            
            
        var mt_name_index=-1;
        var mt_revenue_data=[0,0,0,0,0,0,0,0,0];
       
            
        res.render('main', 
                   
        {'name': name,'email': req.session.email, 'bankname': bankname, 'bankaccount':bankaccount ,'mt_number' : mt_number,mt_event_data : data, mt_name: mt_name, mt_name_index: mt_name_index, mt_revenue_date:mt_revenue_date,mt_revenue_data : mt_revenue_data });
            
              
        
        });
        connection.end();    
        }
        
        else{
            
        var mt_name = mysql.escape(rows[0].MT_NAME);
        
        connection.query(
            
        'SELECT DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -2 MONTH),"%Y-%m") AS P_PREMONTH, DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -1 MONTH),"%Y-%m") AS PREMONTH,DATE_FORMAT(NOW(),"%Y-%m") AS NOW, (SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_EXPENSE ELSE 0 END)) AS P_PREMONTH_PAST, SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS P_PREMONTH_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_EXPENSE ELSE 0 END) AS P_PREMONTH_EXPENSE,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_EXPENSE ELSE 0 END )) AS PREMONTH_PAST, SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS PREMONTH_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_EXPENSE ELSE 0 END ) AS PREMONTH_EXPENSE,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(NOW()) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(NOW()) THEN MT_EXPENSE ELSE 0 END )) AS NOW_PAST,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(NOW()) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS NOW_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(NOW()) THEN MT_EXPENSE ELSE 0 END ) AS NOW_EXPENSE FROM MEETING_REVENUE'       
            
        ,function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
        
        var mt_revenue_data= new Array();
        var mt_revenue_date= new Array();  
         
        var mt_name_index=0;
        
        mt_revenue_date.push(rows[0].P_PREMONTH);
        mt_revenue_date.push(rows[0].PREMONTH);
        mt_revenue_date.push(rows[0].NOW);    
        mt_revenue_data.push(rows[0].P_PREMONTH_PAST);
        mt_revenue_data.push(rows[0].P_PREMONTH_PROFIT);
        mt_revenue_data.push(rows[0].P_PREMONTH_EXPENSE);
        mt_revenue_data.push(rows[0].PREMONTH_PAST);
        mt_revenue_data.push(rows[0].PREMONTH_PROFIT);
        mt_revenue_data.push(rows[0].PREMONTH_EXPENSE);
        mt_revenue_data.push(rows[0].NOW_PAST);
        mt_revenue_data.push(rows[0].NOW_PROFIT);
        mt_revenue_data.push(rows[0].NOW_EXPENSE); 
            
        res.render('main', 
                   
        {'name': name,'email': req.session.email, 'bankname': bankname, 'bankaccount':bankaccount ,'mt_number' : mt_number,mt_event_data : data, mt_name: mt_name, mt_name_index: mt_name_index, mt_revenue_date:mt_revenue_date,mt_revenue_data : mt_revenue_data });
            
        connection.end();        
        
       
        });
    }
            
        });
            
    });
            
    });
    
    
    });        
          
    
    }
        
          
    else{    
        res.redirect('/');
    } 
        
        
});





 router.post('/viewOtherRevenue', function(req, res, next) {
        
     
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);

        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        
        var mt_name_index= Number(req.body.index)+Number(req.body.direction);
        
     
     
     
        connection.query(
            
        'SELECT COUNT(MT_NAME) AS MT_NUMBER FROM MEETING_INFO WHERE USER_EMAIL='+user_email,function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        }
       
        
         
        var mt_array=new Array();
        
        for (i=0;i<rows[0].MT_NUMBER;i++){
            
            mt_array.push(i);
            
        }
            
        
            
        if(mt_name_index<0){
            
          var mt_name_index2= mt_array[mt_array.length-1] 
        
            
        }
           
        else if(mt_name_index==mt_array.length){
            
          var mt_name_index2= mt_array[0]    
          
        }
            
        else{
            
          var mt_name_index2= mt_array[mt_name_index];
            
            
        }
        
      
       
               
        connection.query(

        'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+' LIMIT '+mt_name_index2+ ',1',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
        } 
            
        
        if(!rows[0].MT_NAME){
        
        var mt_name=null;
        var mt_name_index=null;
        var mt_revenue_data=null;
        var mt_revenue_date=null; 
            
        res.json({mt_name: mt_name, mt_name_index: mt_name_index, mt_revenue_date:mt_revenue_date,mt_revenue_data : mt_revenue_data });
            
        connection.end();      
        
        }
        
        else{
         
        var mt_name = mysql.escape(rows[0].MT_NAME);
            
        connection.query(
            
        'SELECT DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -2 MONTH),"%Y-%m") AS P_PREMONTH, DATE_FORMAT(DATE_ADD(NOW(), INTERVAL -1 MONTH),"%Y-%m") AS PREMONTH,DATE_FORMAT(NOW(),"%Y-%m") AS NOW, (SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_EXPENSE ELSE 0 END)) AS P_PREMONTH_PAST, SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS P_PREMONTH_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(DATE_ADD(NOW(), INTERVAL -2 MONTH)) THEN MT_EXPENSE ELSE 0 END) AS P_PREMONTH_EXPENSE,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_EXPENSE ELSE 0 END )) AS PREMONTH_PAST, SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS PREMONTH_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(DATE_ADD(NOW(), INTERVAL -1 MONTH)) THEN MT_EXPENSE ELSE 0 END ) AS PREMONTH_EXPENSE,(SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(NOW()) THEN MT_PROFIT_ACTUAL ELSE 0 END ) -SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)<=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) < MONTH(NOW()) THEN MT_EXPENSE ELSE 0 END )) AS NOW_PAST,SUM(CASE WHEN MT_REVENUE_DISTINCT="P" AND MT_PROFIT_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) =MONTH(NOW()) THEN MT_PROFIT_ACTUAL ELSE 0 END) AS NOW_PROFIT,SUM(CASE WHEN MT_REVENUE_DISTINCT="E" AND MT_EXPENSE_YN="Y" AND USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' AND YEAR(MT_REVENUE_DATE)=YEAR(NOW()) AND MONTH(MT_REVENUE_DATE) = MONTH(NOW()) THEN MT_EXPENSE ELSE 0 END ) AS NOW_EXPENSE FROM MEETING_REVENUE'       
            
        ,function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
        
        var mt_revenue_data= new Array();
        var mt_revenue_date= new Array();  
        
        mt_revenue_date.push(rows[0].P_PREMONTH);
        mt_revenue_date.push(rows[0].PREMONTH);
        mt_revenue_date.push(rows[0].NOW);    
        mt_revenue_data.push(rows[0].P_PREMONTH_PAST);
        mt_revenue_data.push(rows[0].P_PREMONTH_PROFIT);
        mt_revenue_data.push(rows[0].P_PREMONTH_EXPENSE);
        mt_revenue_data.push(rows[0].PREMONTH_PAST);
        mt_revenue_data.push(rows[0].PREMONTH_PROFIT);
        mt_revenue_data.push(rows[0].PREMONTH_EXPENSE);
        mt_revenue_data.push(rows[0].NOW_PAST);
        mt_revenue_data.push(rows[0].NOW_PROFIT);
        mt_revenue_data.push(rows[0].NOW_EXPENSE); 
        
        
        res.json({mt_name: mt_name, mt_name_index: mt_name_index2, mt_revenue_date:mt_revenue_date,mt_revenue_data : mt_revenue_data });
         connection.end();  
                
            
        
        });
        
         
        
         
        
       
        }
        });
            
    });
            
    
 });
    

module.exports = router;



