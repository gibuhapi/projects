var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');

router.post('/create', function(req, res, next) {
    
  
        var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
        var mt_number =req.session.mt_number;
        var mt_name = mysql.escape(req.session.mt_name);
        var db_connection= require('../routes/db_connection');
        var connection= mysql.createConnection(db_connection);
    
        var mt_event_name= mysql.escape(req.body.event_name);
        var mt_event_round= mysql.escape(req.body.event_round);
        var mt_event_date= mysql.escape(req.body.event_date+" "+req.body.event_time);

        var mt_event_time= mysql.escape(req.body.event_time);
        
    
        if(req.body.event_location){
        
        var mt_event_location= mysql.escape(req.body.event_location);
        
        }
    
        else{
            
        var mt_event_location= mysql.escape('미정');    
        
        }
        
        if(req.body.event_url){

        var mt_event_url = mysql.escape(req.body.event_url);
    
        }
    
        else{
            
        var mt_event_url = null; 
        
        }
    
       
        connection.query( 
        'INSERT MEETING_EVENT(USER_EMAIL,MT_NAME,MT_EVENT_NAME,MT_EVENT_ROUND,MT_EVENT_DATE,MT_EVENT_TIME,MT_EVENT_LOCATION,MT_EVENT_URL) VALUES('
        +user_email+','+mt_name+','+mt_event_name+','+mt_event_round+','+mt_event_date+','+mt_event_time+','+mt_event_location+','+mt_event_url+')',
                         
        function(err,rows,fields){
        
        
        if (err) {
            console.error(err);
            res.json({result:"error"});
            throw err;
        }
       
   
        connection.query(
            
        'SELECT MT_EVENT_NUMBER,MT_EVENT_NAME,MT_EVENT_ROUND,MT_EVENT_LOCATION ,MT_EVENT_DATE FROM MEETING_EVENT WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mt_name+' ORDER BY MT_EVENT_NUMBER DESC LIMIT 0,1',
            
        function(err,rows,fields){
                
        if (err) {            
            console.error(err);
            res.json({result:"error"});
            throw err;
        }

         var mt_event_number = rows[0].MT_EVENT_NUMBER; 
         var mt_event_name = rows[0].MT_EVENT_NAME;        
         var mt_event_round = rows[0].MT_EVENT_ROUND;        
         var mt_event_location = rows[0].MT_EVENT_LOCATION;        
         var mt_event_date = rows[0].MT_EVENT_DATE;        
        
                
        connection.query( 
        
        'INSERT MEETING_REVENUE(USER_EMAIL,MT_NAME,MT_EXPENSE,MT_EXPENSE_YN,MT_EVENT_NUMBER,MT_EXPENSE_NAME,MT_EXPENSE_ROUND,MT_EXPENSE_LOCATION,MT_REVENUE_DISTINCT,MT_REVENUE_DATE) VALUES('
        +user_email+','+mt_name+', 0,"Y",'+mt_event_number+','+mysql.escape(mt_event_name)+','+mysql.escape(mt_event_round)+','+mysql.escape(mt_event_location)+',"E",'+mysql.escape(mt_event_date)+')',
                         
        function(err,rows,fields){
          
        
        if (err) {
            console.error(err);
            res.json({result:"error"});
            throw err;
        }    
        
       res.json({result:"success"});
       connection.end();     
       console.log(mt_event_name+" INSERTED SUCCESSFULLY");      
         
        
        });


        });
        });
    
    
});


router.post('/select', function(req, res, next) {
    
    
    
    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number =req.session.mt_number;
    var mt_name = mysql.escape(req.session.mt_name);
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    var event_number = req.body.event_number;
    var data = new Array();
    
    
    
    connection.query(
    
    'SELECT MT_EVENT_NUMBER, MT_EVENT_NAME,DATE_FORMAT(MT_EVENT_DATE,"%Y-%m-%d") AS MT_EVENT_DATE,MT_EVENT_ROUND,MT_EVENT_TIME,MT_EVENT_LOCATION,MT_EVENT_URL FROM MEETING_EVENT WHERE MT_EVENT_NUMBER='+event_number,
                     
                
    function(err,rows,fields){           
            
        
        if (err) {
            console.error(err);
            throw err;
        }
                 
          
                 
        for(i=0;i<rows.length;i++){
                      
            data.push(rows[i].MT_EVENT_NUMBER);
            data.push(rows[i].MT_EVENT_NAME);    
            data.push(rows[i].MT_EVENT_ROUND);  
            data.push(rows[i].MT_EVENT_DATE);
            data.push(rows[i].MT_EVENT_TIME);     
            data.push(rows[i].MT_EVENT_LOCATION);
            data.push(rows[i].MT_EVENT_URL);
                
                      
        } 
    
        res.json({event_data : data});
        connection.end();
    
    });
    
});




router.post('/modify', function(req, res, next) {
    
   
    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number =req.session.mt_number;
    var mt_name = mysql.escape(req.session.mt_name);
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    var event_number = req.body.event_number;
    var data = new Array();

    console.log(req.body);
    
     var mt_event_name= mysql.escape(req.body.event_name);
     var mt_event_round= mysql.escape(req.body.event_round);
    var mt_event_date= mysql.escape(req.body.event_date+" "+req.body.event_time);

    var mt_event_time= mysql.escape(req.body.event_time);
        
    
    if(req.body.event_location){
        
        var mt_event_location= mysql.escape(req.body.event_location);
        
    }
    
    else{
            
        var mt_event_location= mysql.escape('미정');    
        
    }
        
    if(req.body.event_url){

        var mt_event_url = mysql.escape(req.body.event_url);
    
    }
    
    else{
            
        var mt_event_url = null; 
        
    }
    
    
     connection.query(
   
    'UPDATE MEETING_EVENT SET MT_EVENT_NAME='+mt_event_name+',MT_EVENT_ROUND='+mt_event_round+',MT_EVENT_DATE='+mt_event_date+',MT_EVENT_TIME='+mt_event_time+',MT_EVENT_LOCATION='+mt_event_location+', MT_EVENT_URL='+mt_event_url+
    ' WHERE MT_EVENT_NUMBER='+event_number+";",function(err,rows,fields){
        
        
    if (err) {
        console.error(err);
        throw err;
    }
                 
     connection.query(
    
    'UPDATE MEETING_REVENUE SET MT_EXPENSE_NAME='+mt_event_name+',MT_EXPENSE_ROUND='+mt_event_round+',MT_REVENUE_DATE='+mt_event_date+' WHERE MT_EVENT_NUMBER='+event_number+";"
        
                
    ,function(err,rows,fields){
        
        
    if (err) {
        console.error(err);
        throw err;
    }
                   
    res.json({result:"success"});
    connection.end();  
      
    
    });
    
    });
});


router.post('/delete', function(req, res, next) {
    
        
    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number =req.session.mt_number;
    var mt_name = mysql.escape(req.session.mt_name);
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    var event_number = req.body.event_number;
    
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    var query = 'DELETE FROM MEETING_EVENT WHERE MT_EVENT_NUMBER='+event_number+';'
    query+= 'DELETE FROM MEETING_REVENUE WHERE MT_EVENT_NUMBER='+event_number+';'
        
        
    connection.query(query,function(err,rows,fields){           
            
        
    if (err) {
        console.error(err);
        throw err;
    }
                 
    
    res.json({result : 'success'});
    connection.end();   
    
    });
    
});


module.exports = router;
