var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');

/* GET home page. */
router.get('/', function(req, res, next) {
   
  res.render('register', { });
 
});


router.post('/', function(req, res, next) {
   
  res.render('register', { });
 
});


router.post('/init', function(req, res, next) {

    var user = {'email':req.body.email,
                'pwd':req.body.pwd_type,
                'name':req.body.name,
                'bankname':req.body.bankname,
                'bankaccount':req.body.bankaccount};

    var user_email= mysql.escape(encryption.AES256Encrypt(user.email));
    var user_pwd=mysql.escape(encryption.SHA256Encrypt(user.pwd)); 
    var user_name=mysql.escape(user.name); 
    var user_bankname=mysql.escape(user.bankname); 
    var user_bankaccount=mysql.escape(encryption.AES256Encrypt(user.bankaccount));


        
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);


    connection.query(
    
    'SELECT * FROM USER WHERE USER_email='+user_email+';',function(err,rows,fields){

    if (err) {
        console.error(err);
        throw err;
    }
        
      
    if(rows.length>0) {
            
        console.log(user_email+'은 이미 가입되었있습니다.해당 이메일을 사용할 수 없음을 사용자에게 알립니다.');
            
        res.json({result :"duplicated"});
        connection.end();
        }
        
    else{
            
        console.log(user_email+'은 등록되지 않았기에 신규 등록함');
            
        connection.query(
            
            
                
        "INSERT INTO USER(USER_EMAIL, USER_PASSWORD,CM_NAME,CM_BANKNAME,CM_BANKACCOUNT,USEYN) VALUES(" +user_email+','+user_pwd+','+user_name+','+user_bankname+","+user_bankaccount+","+"'Y'"+")", function(err,rows,fields){
             
        if (err) {
            
            console.error(err);
            throw err;
            res.json({result :"fail"});  
        }

        res.json({ result :"success"});
        connection.end();
        console.log('회원가입했다고 ajax로 회신보냄');
                
         
        });  
                

                
    }
    
        
    });

});





router.get('/modify', function(req, res, next) {
  
  
 if(req.session.email){
   
     
  var user_email=encryption.AES256Encrypt(req.session.email); 
  var db_connection= require('../routes/db_connection');
  var connection= mysql.createConnection(db_connection);

  connection.query(
    
  'SELECT * FROM USER WHERE USER_email='+mysql.escape(user_email)+';',function(err,rows,fields){
    
        
  if (err) {
        console.error(err);
        throw err;
  }
    
        
  var cm_bankaccount=encryption.AES256Decrypt(rows[0].CM_BANKACCOUNT);   

  res.render('register_modify',{
        
        'email' : req.session.email,
        'cm_name' : rows[0].CM_NAME,
        'cm_bankname': rows[0].CM_BANKNAME,
        'cm_bankaccount' : cm_bankaccount
  });
  connection.end();      
    
});
}
    
else{
    
res.redirect('/');
    
}
});
         

router.post('/modify', function(req, res, next) {

 if(req.session.email){
   
     
  var user_email=encryption.AES256Encrypt(req.session.email); 
  var db_connection= require('../routes/db_connection');
  var connection= mysql.createConnection(db_connection);

  connection.query(
    
  'SELECT * FROM USER WHERE USER_email='+mysql.escape(user_email)+';',function(err,rows,fields){
    
        
  if (err) {
        console.error(err);
        throw err;
  }
    
        
  var cm_bankaccount=encryption.AES256Decrypt(rows[0].CM_BANKACCOUNT);   

  res.render('register_modify',{
        
        'email' : req.session.email,
        'cm_name' : rows[0].CM_NAME,
        'cm_bankname': rows[0].CM_BANKNAME,
        'cm_bankaccount' : cm_bankaccount
  });
  connection.end();      
    
});
}
    
else{
    
res.redirect('/');
    
}
});
   

module.exports = router;
