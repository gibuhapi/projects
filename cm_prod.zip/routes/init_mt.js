var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');

router.get('/', function(req, res, next) {
        
        
    res.redirect('/');
    
    
});

    
router.post('/create', function(req, res, next) {
        
   
    console.log('Number of JSON Data key by Post : '+Object.keys(req.body).length);      
    
    var value = [];
        
      for(var key in req.body) {

      value.push(req.body[key]);
    }
        
    
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    

    var user_email=mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_name= mysql.escape(req.body.mt_name);
    var mt_payment_type= mysql.escape(req.body.mt_payment_type);
    
        
    if(req.body.mt_payment_type=="필요시만"){
        
        var mt_payment_date =null;
    }
    
    else{
        
       var mt_payment_date =req.body.mt_payment_date; 
     
    }
        
    var mt_cm_name= mysql.escape(req.body.cm_name);
    var mt_cm_bankname= mysql.escape(req.body.cm_bankname);
    var mt_cm_bankaccount= mysql.escape(encryption.AES256Encrypt(req.body.cm_bankaccount));
        
        
    
    connection.query(
        
        'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+';', 
        
        function(err,rows,fields){
        
        console.log(rows.length);
            
             if(rows.length>=5){    
                console.log('생성된 모임의 개수가 '+ rows.length+'여서 생성하지 않음');
                res.json({result:'fail'});
              
                return false;
            } 
            
            else{
          
                for(i=0;i<rows.length;i++) {

                    if(req.body.mt_name == rows[i].MT_NAME) {
                        
                    res.json({result: 'duplicated'});
                    console.log('사용자가 입력한 값'+ mt_name+ '이 DB검색결과:'+ rows[i].MT_NAME+'와 같은값으로 검색되어 생성하지 않음');
                    
                        
                    return false;
                }
            }
        }
        
  
        connection.query(
        
        'INSERT MEETING_INFO(USER_EMAIL,MT_NAME,MT_PAYMENT_TYPE,MT_PAYMENT_DATE,MT_CM_NAME,MT_CM_BANKNAME,MT_CM_BANKACCOUNT) VALUES(' 
        +user_email+','+mt_name+','+mt_payment_type+','+mt_payment_date+','+mt_cm_name+','+mt_cm_bankname+','+mt_cm_bankaccount+');',
        
        function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
            res.json({result:"error"});
            return false;
        }
            
            
        }
   
    );
        
 
            
    switch (Object.keys(req.body).length) {
            
        case 8 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4]; 
                
                connection.query(    
                
               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');',    

                function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                    res.json({result:'error'});
                    return false;
                }

                res.json({result:'success'});
               
                    
                }
                    
                    
            );        
         
        break;      

        case 10 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6]; 

            connection.query(    



               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');'); 

                
            connection.query('INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');', 

                function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                    res.json({result:'error'});
                    return false;
                }

                res.json({result:'success'});
                

                }
            );      
         
        break;  

        case 12 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6];
            var mt_payment_group3= mysql.escape(value[7]);
            var mt_payment_amount3 = value[8];   

                connection.query(    

               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');'); 

                 connection.query(  
               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');');
                 
                connection.query( 
                'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group3+','+mt_payment_amount3+');', 

                function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                    res.json({result:'error'});
                    return false;
                }

                res.json({result:'success'});
               
                
                }
            );      
        
        break;        

        case 14 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6];
            var mt_payment_group3= mysql.escape(value[7]);
            var mt_payment_amount3 = value[8];
            var mt_payment_group4= mysql.escape(value[9]);
            var mt_payment_amount4 = value[10];   

                connection.query(    

                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');');

                connection.query(  
                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');');
                
                connection.query(  

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group3+','+mt_payment_amount3+');');
                
                connection.query(  

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group4+','+mt_payment_amount4+');',

                    function(err,rows,fields){

                    if (err) {
                        console.error(err);
                        throw err;
                        res.json({result:'error'});
                        return false;
                    }

                    res.json({result:'success'});

                    }
                );   
        break;       

        case 16 :

            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6];
            var mt_payment_group3= mysql.escape(value[7]);
            var mt_payment_amount3 = value[8];
            var mt_payment_group4= mysql.escape(value[9]);
            var mt_payment_amount4 = value[10];
            var mt_payment_group5= mysql.escape(value[11]);
            var mt_payment_amount5 = value[12];   


            connection.query(    

                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');');
                
            connection.query(    


                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');');
                
            connection.query(    

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group3+','+mt_payment_amount3+');');

            connection.query(        
                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group4+','+mt_payment_amount4+');');
                
            connection.query(        

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group5+','+mt_payment_amount5+');',

                    function(err,rows,fields){

                    if (err) {
                        console.error(err);
                        throw err;
                        res.json({result:'error'});
                        return false;
                    }

                    res.json({result:'success'});
                       

                    }
                );   

        break; 
        
        default :
          
         
       connection.query(    
        
      
            
           'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME) VALUES('
           +user_email+','+mt_name+');',    

            function(err,rows,fields){

            if (err) {
                console.error(err);
                throw err;
                res.json({result:'error'});
                return false;
            }

             res.json({result:'success'});
              

            }
        );

        break;          
            
            
    }
  
        
    connection.end();     
    
 
    
           
});

});


router.post('/modify', function(req, res, next) {
    
    
    console.log(req.body);
    console.log('Number of JSON Data key by Post : '+Object.keys(req.body).length);      
    
    var value = [];
        
      for(var key in req.body) {

      value.push(req.body[key]);
    }
        
   
   
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    

    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_name= mysql.escape(req.body.mt_name);
    var mt_payment_type= mysql.escape(req.body.mt_payment_type);
    
    if(req.body.mt_payment_type=="필요시만"){
        
        var mt_payment_date =null;
    }
    
    else{
        
       var mt_payment_date =req.body.mt_payment_date; 
     
    }
    
    var mt_cm_name= mysql.escape(req.body.cm_name);
    var mt_cm_bankname= mysql.escape(req.body.cm_bankname);
    var mt_cm_bankaccount = mysql.escape(encryption.AES256Encrypt(req.body.cm_bankaccount));
    
     var query = "";
     query+= 'UPDATE MEETING_INFO SET MT_PAYMENT_TYPE='+mt_payment_type+',MT_PAYMENT_DATE='+mt_payment_date+',MT_CM_NAME='+mt_cm_name+ ',MT_CM_BANKNAME='+mt_cm_bankname+',MT_CM_BANKACCOUNT='+mt_cm_bankaccount+ ' WHERE USER_EMAIL='+user_email+'AND MT_NAME='+mt_name+';'
    
     query+='DELETE FROM PAYMENT_SETTING WHERE USER_EMAIL='+user_email+'AND MT_NAME='+mt_name+';'
    
    
     connection.query(query, function(err,rows,field){
         
     if (err) {
                console.error(err);
                throw err;
            }    
         
     });

       
            
    switch (Object.keys(req.body).length) {
            
        case 8 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4]; 
                
                connection.query(    
                
               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');',    

                function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                    res.json({result:'error'});
                    return false;
                }

                res.json({result:'success'});
                 
                    
                }
                    
                    
            );        
         
        break;      

        case 10 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6]; 

            connection.query(    



               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');'); 

                
            connection.query('INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');', 

                function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                    res.json({result:'error'});
                    return false;
                }

                res.json({result:'success'});
               

                }
            );      
         
        break;  

        case 12 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6];
            var mt_payment_group3= mysql.escape(value[7]);
            var mt_payment_amount3 = value[8];   

                connection.query(    

               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');'); 

                 connection.query(  
               'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');');
                 
                connection.query( 
                'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
               +user_email+','+mt_name+','+mt_payment_group3+','+mt_payment_amount3+');', 

                function(err,rows,fields){

                if (err) {
                    console.error(err);
                    throw err;
                    res.json({result:'error'});
                    return false;
                }

                res.json({result:'success'});
               
                }
            );      
        
        break;        

        case 14 :
            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6];
            var mt_payment_group3= mysql.escape(value[7]);
            var mt_payment_amount3 = value[8];
            var mt_payment_group4= mysql.escape(value[9]);
            var mt_payment_amount4 = value[10];   

                connection.query(    

                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');');

                connection.query(  
                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');');
                
                connection.query(  

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group3+','+mt_payment_amount3+');');
                
                connection.query(  

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group4+','+mt_payment_amount4+');',

                    function(err,rows,fields){

                    if (err) {
                        console.error(err);
                        throw err;
                        res.json({result:"error"});
                        return false;
                    }

                    res.json({result:"success"});
                     

                    }
                );   
        break;       

        case 16 :

            var mt_payment_group1= mysql.escape(value[3]);
            var mt_payment_amount1 = value[4];
            var mt_payment_group2= mysql.escape(value[5]);
            var mt_payment_amount2 = value[6];
            var mt_payment_group3= mysql.escape(value[7]);
            var mt_payment_amount3 = value[8];
            var mt_payment_group4= mysql.escape(value[9]);
            var mt_payment_amount4 = value[10];
            var mt_payment_group5= mysql.escape(value[11]);
            var mt_payment_amount5 = value[12];   


            connection.query(    

                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group1+','+mt_payment_amount1+');');
                
            connection.query(    


                   'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group2+','+mt_payment_amount2+');');
                
            connection.query(    

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group3+','+mt_payment_amount3+');');

            connection.query(        
                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group4+','+mt_payment_amount4+');');
                
            connection.query(        

                    'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP,MT_PAYMENT_AMOUNT) VALUES('
                   +user_email+','+mt_name+','+mt_payment_group5+','+mt_payment_amount5+');',

                    function(err,rows,fields){

                    if (err) {
                        console.error(err);
                        throw err;
                        res.json({result:'error'});
                        return false;
                    }

                    res.json({result:'success'});
                    

                    }
                );   

        break; 
        
        default :
          
         
       connection.query(    
        
      
            
           'INSERT PAYMENT_SETTING(USER_EMAIL,MT_NAME) VALUES('
           +user_email+','+mt_name+');',    

            function(err,rows,fields){

            if (err) {
                console.error(err);
                throw err;
                res.json({result:'error'});
                return false;
            }

             res.json({result:'success'});
             

            }
        );

        break;          
            
            
    }
  
        
    connection.end();     
    
 
    
           
});



  router.post('/view', function(req, res, next) {
    
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
     
    var user_email= req.session.email;
    var email= encryption.AES256Encrypt(user_email);
        
    connection.query(
    
        
        'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+mysql.escape(email)+';', 
        
        function(err,rows,fields){
        
        
           var data=new Array();
           for(i=0;i<rows.length;i++){
            
            if(i<rows.length-1){
            data.push(rows[i].MT_NAME);          
            }
            else {
            data.push(rows[i].MT_NAME);     
                
            }
        }
           
            console.log(data);
            res.json({ mtdata : data, result :'success',number: rows.length,email: user_email });
            connection.end();
                
        });
      
  });



module.exports = router;
