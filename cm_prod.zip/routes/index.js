var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');

router.get('/', function(req, res, next) {
  
    

    if(req.session.email){

        res.redirect('/main');

    }

    else{

      res.render('index', {});

    }      

});

router.post('/', function(req, res, next) {
  
     if(req.session.email){

        res.redirect('/main');

    }

    else{

      res.render('index', {});

    }      

});

module.exports = router;
