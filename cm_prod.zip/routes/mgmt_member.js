var express = require('express');
var router = express.Router();
var mysql= require('mysql');
var encryption= require('../routes/encryption');
var async = require('async');


router.post('/create', function(req, res, next) {
    
    console.log(req.body);
    console.log("Number of JSON Data key by Post : "+Object.keys(req.body).length);      
    
    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number =req.session.mt_number;
   
    var value = [];
   
    
    for(var key in req.body) {
      value.push(req.body[key]);
    }

    console.log(value);
    
    var mt_memb_name= [];
    var mt_memb_phone= [];
    var mt_payment_group= [];
    
    
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    for(i=0; i<value.length;i++){
      
            switch (i%3) {

             case 0:      
             mt_memb_name.push(value[i]);      
             break;

             case 1:
             mt_memb_phone.push(value[i]);
             break;

             case 2:   
             mt_payment_group.push(value[i]);
             break;
                 
            }
    }
    
    console.log(mt_memb_name);
    console.log(mt_memb_phone);
    console.log(mt_payment_group);
    

    connection.query(

    'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+' LIMIT '+mt_number+',1',function(err,rows,fields){

        if (err) {
                console.error(err);
                throw err;
        }
               
            
    var mt_name = rows[0].MT_NAME;
    console.log("MT_NAME SELECT COMPLETE");        
    
    for(i=0;i<mt_memb_name.length;i++){ 
         
        connection.query(
        
        'INSERT MEETING_MEMB(USER_EMAIL,MT_NAME,MT_MEMB_NAME,MT_MEMB_PHONE,MT_PAYMENT_GROUP) VALUES(' 
        +user_email+','+mysql.escape(mt_name)+','+mysql.escape(mt_memb_name[i])+','+mysql.escape(mt_memb_phone[i])+','+mysql.escape(mt_payment_group[i])+');',function(err,rows,fields){

        if (err) {
            console.error(err);
            throw err;
            res.json({result:"error"});
        }
            
        console.log("INSERT COMPLETE");            
           
        });
            
    }
        
     async.waterfall(tasks, function (err) {
        
        if (err)
            console.log('err');
        else
            console.log('done');
        
        res.json({result: "success"});   
        connection.end();
    
    });    
});
     
    var tasks = [
        
    function (callback) {
        
        
        connection.query(
            
            'SELECT USER_EMAIL,MT_NAME,MT_MEMB_NAME,MT_MEMB_NUMBER ,MT_PAYMENT_AMOUNT,MT_MEMB_JOIN FROM MEETING_MEMB LEFT JOIN PAYMENT_SETTING USING(USER_EMAIL,MT_NAME,MT_PAYMENT_GROUP) ORDER BY MT_MEMB_NUMBER DESC LIMIT 0,'+mt_memb_name.length+';',

            function(err,rows,fields){
                
            if (err) {            
            return callback(err);
            
            }
                

           
            var data = new Array(rows.length); 
            
            for (var i=0; i<rows.length; i++) {
            data[i] = new Array(0); 
            
            }
            
            for(i=0;i<rows.length;i++){
            
            data[i].push(rows[i].USER_EMAIL);
            data[i].push(rows[i].MT_NAME);       
            data[i].push(rows[i].MT_PAYMENT_AMOUNT);
            data[i].push(rows[i].MT_MEMB_NAME);    
            data[i].push(rows[i].MT_MEMB_JOIN);
            data[i].push(rows[i].MT_MEMB_NUMBER);      

            
            }
                
           callback(null,data);
            
            
            
    });
    },
        
        
    function(data, callback){
        
        console.log('여기까지 들어옴2');
        console.log(data);
        
        for(i=0;i<data.length;i++){
        
        connection.query(
            
            'INSERT MEETING_REVENUE(USER_EMAIL,MT_NAME,MT_PROFIT_YN,MT_PROFIT,MT_PROFIT_DETAIL,MT_REVENUE_DATE,MT_MEMB_NUMBER,MT_REVENUE_DISTINCT) VALUES(?,?,"N",?,?,?,?,"P")',data[i],function(err,rows,fields){
                
            if (err) {
            
            console.log(err);    
            return callback(err);
            }
        });
        
        }
  
        callback(null);
            
   
    
    }
];

    

 
});
    


router.post('/modify', function(req, res, next) {
    
    console.log(req.body);
   
    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number =req.session.mt_number;
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    
    var value1 = new Array();
    var value2= new Array();
   
    for(var key in req.body) {value1.push(key);}
    console.log(value1);
    
    for(var key in req.body) {value2.push(req.body[key]);}
    console.log(value2);

    
    var queryData1 = new Array((value2.length)/3); 
            
    for (var i=0; i<((value2.length)/3); i++) {
        queryData1[i] = new Array(0); 
            
        }
    
    var queryData2 = new Array((value2.length)/3); 
            
    for (var i=0; i<((value2.length)/3); i++) {
        queryData2[i] = new Array(0); 
            
        }
    
     for(i=0;i<value1.length;i++){
        
        if((i%3)=='0'){
         
        queryData1[parseInt(i/3)].push(value2[i]);  
        queryData2[parseInt(i/3)].push(value2[i]); 
        
        } 
        
        else if((i%3)=='1'){
            
        queryData1[parseInt(i/3)].push(value2[i]);     
        
        } 
        
        else {
            
        queryData1[parseInt(i/3)].push(value2[i]); 
        queryData1[parseInt(i/3)].push(value1[i].substring(27,30));     
        queryData2[parseInt(i/3)].push(value2[i]);
        queryData2[parseInt(i/3)].push(value1[i].substring(27,30));     
        }
    }
    
    console.log(queryData1);
    console.log(queryData2);
    
  
    
    connection.query(
        
    'SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+' LIMIT '+mt_number+',1',function(err,rows,fields){

            if (err) {
                console.error(err);
                throw err;
            }
        
    var mt_name = rows[0].MT_NAME;
    console.log(mt_name);
    
   
    var query1='UPDATE MEETING_MEMB SET MT_MEMB_NAME=?,MT_MEMB_PHONE=?,MT_PAYMENT_GROUP=? WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mysql.escape(mt_name)+' AND MT_MEMB_NUMBER=?';
    
   
        
    var query2='UPDATE MEETING_REVENUE SET MT_PROFIT_DETAIL=?, MT_PROFIT=(SELECT MT_PAYMENT_AMOUNT FROM PAYMENT_SETTING WHERE USER_EMAIL='+user_email+' AND MT_NAME='+mysql.escape(mt_name)+' AND MT_PAYMENT_GROUP=?) WHERE MT_MEMB_NUMBER=?';
    
  
    console.log(query1);
    console.log(query2);
    
 
        
    for(i=0;i<queryData1.length;i++){
        
        console.log('여기까지 들어옴');
        connection.query(query1,queryData1[i],

            function(err,rows,fields){

            if (err) {
                    console.error(err);
                    throw err;
            }
  

        });
        
        
        
    }  
        
        
    for(i=0;i<queryData2.length;i++){
        
        console.log('여기까지 들어옴');
        connection.query(query2,queryData2[i],

            function(err,rows,fields){

            if (err) {
                    console.error(err);
                    throw err;
            }
  

        });
        
        
        
    }      

});
    
    
    
    res.json({ result : 'success'});        
    
     
});
    
    
  
    
    
    //res.json({ result : 'success'});    

    


router.post('/delete', function(req, res, next) {
    
   
    var user_email= mysql.escape(encryption.AES256Encrypt(req.session.email));
    var mt_number =req.session.mt_number;
    var memberID = req.body.memberID;
    
    var db_connection= require('../routes/db_connection');
    var connection= mysql.createConnection(db_connection);
    
    if(memberID=="all"){
        
     connection.query(

        'DELETE FROM MEETING_MEMB WHERE MT_NAME=(SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+' LIMIT '+mt_number+',1) AND USER_EMAIL='+user_email+' ;',function(err,rows,fields){

            if (err) {
                console.error(err);
                throw err;
            }
            
        res.json({ result : 'success'});
            
            
        });   
        
    }
    
    else{
        
      connection.query(

        'DELETE FROM MEETING_MEMB WHERE MT_NAME=(SELECT MT_NAME FROM MEETING_INFO WHERE USER_EMAIL='+user_email+' LIMIT '+mt_number+',1) AND USER_EMAIL='+user_email+' AND MT_MEMB_NUMBER='+memberID+';',function(err,rows,fields){

            if (err) {
                console.error(err);
                throw err;
            }
            
         res.json({ result : 'success'});
            
            
        });   
        
    }   
              
});

module.exports = router;
