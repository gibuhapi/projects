var crypto = require('crypto');

var encryption =module.exports = {
    
    
    SHA256Encrypt : function(data){ 
    var enc = crypto.createHash('sha256').update(data);
    var encResult=  enc.digest('hex');
    return encResult;
    
    }
    
    ,AES256Encrypt: function(data){    
    var enc = crypto.createCipher('aes-256-cbc','cm');
    var encResult = enc.update(data,'utf8','hex');
    encResult += enc.final('hex');  
    return encResult;
        
    }
    
    ,AES256Decrypt : function(data){ 
    var dec = crypto.createDecipher('aes-256-cbc','cm');
    var decResult=  dec.update(data,'hex','utf8');
    decResult += dec.final('utf8'); 
    return decResult;
        
    }
   
}

