function viewList() {


                $.ajax({
                         url: '/init_mt/view',
                         dataType : 'json',
                         type: "POST",
                         data: { },                  
                         success: function(data){

                              console.log(data);

                    if(data.result == "success"){


                        $('#mt_list').empty(); 

                        var addlist="<br><br>"        

                        if(data.number=='0'){

                             addlist+="&nbsp;&nbsp;아직 모임이 없습니다 <br>&nbsp;&nbsp;왼쪽 추가를 터치해주세요";

                             $('#mt_list').append(addlist).trigger('create');
                             $('#mt_list').listview('refresh');        

                            }

                        else{

                            for(i=0;i<data.number;i++) {
 
                            addlist+="<li><a id=mt"+i+" onclick=goToMtmain("+i+")>"+data.mtdata[i].toString()+"</a></li>"; 

                            } 

                             $('#mt_list').append(addlist).trigger('create');
                             $('#mt_list').listview('refresh');



                            }
                        }
                    }

                });
 }



function addList(){
               
            
        var group_select_text=
        $('#payment_group_select0 option').map(function() {
        
           return $(this).val();        
        });
    
        console.log(group_select_text);
        
        var i=Number($('#new_member_list input:last').attr('id').substring(12,15))+1;
               
        var addData="";
        
        addData += "<tr><td><input type='text' id='member_name"+i+"' name='member_name"+i+"' placeholder='이름' maxlength='4'></td>";
            
        addData +="<td><input type='text' id='member_phone"+i+"' name='member_phone"+i+"' placeholder='전화번호(-제외)' maxlength='11',numberOnly='true' value='010'></td>";
        addData +="<td colspan='2'><select id='payment_group_select"+i+"' name='payment_group_select"+i+"'>";
        
        for(i=0;i<group_select_text.length;i++){
        addData +="<option>"+group_select_text[i]+"</option>"
        }
    
        addData +="</select></td></tr>";
        $("#new_member_list").append(addData).trigger("create");
        
}

function initMember(){

        
        var j= Number($('#new_member_list input:last').attr('id').substring(12,15))+1;
        
        for(i=0; i<j;i++){
    
        if(!($('#member_name'+i).val())||!($('#member_phone'+i).val())||!$('#payment_group_select'+i).val()) {
        
        alert(Number(i)+1+'번째 열의 값을 입력해주세요');
            
        return false;
        break;   
        
        }
        }
    
            
        if(confirm('회원 등록을 하시겠습니까?')==false){ 
                
        return false; 
                
         }
                
         var member_data= $('#member_add_form').serialize();
        
                     alert(member_data);
    
                       $.ajax({
                         url: '/mgmt_member/create',
                         dataType : 'json',
                         type: "POST",
                         data: member_data,                     
                         success: function(data){

                             console.log(data);

                            if (data.result =='error'){

                             alert('알 수 없는 에러로 모임생성에 실패했습니다');

                             }

                             else{
 
                             alert('정상적으로 저장되었습니다.');   
                             goToMtmember();    
                                 
                             }


                            }
                       });
                    
}


function modifyMember(){

var inputResult=true;
var selectResult=true;
    
    $('#member_modify_list input').map(function() {


                if($(this).val()==""){

                alert('실패');    
                inputResult=false;
                } 

    });


    $('#member_modify_list select').map(function() {

                if($(this).val()==""){
                alert('실패');     
                selectResult=false;  
                }


    });
      
    if(inputResult&selectResult){
        
        if(confirm('회원 수정을 하시겠습니까?')==false){ 

            return false; 

         }
        
   
        var member_data= $('#member_modify_form').serialize();
        
            alert(member_data);
    
                $.ajax({
                    url: '/mgmt_member/modify',
                    dataType : 'json',
                    type: "POST",
                    data: member_data,                     
                    success: function(data){

                        console.log(data);

                        if (data.result =='success'){

                        alert('정상적으로 수정되었습니다.');   
                        goToMtmember();  
                               

                        }

                        else{
 
                        alert('알 수 없는 에러로 멤버수정에 실패했습니다'); 
                                 
                        }


                    }
                });
                    
        }
      
    else {
        
    alert('모든값을 입력해주세요');
    return false;    
    
    }
}

function modifyMemberList(i){

 alert('멤버일부수정누름');
    
 var name_val=$('#mt_memb'+i+' td:nth-child(1)').text();
 var phone_val=$('#mt_memb'+i+' td:nth-child(2)').text();   
 var select_val=$('#mt_memb'+i+' td:nth-child(3)').text();    
 
 
  
 var group_select_text=
        
     $('#payment_group_select0 option').map(function() {
        
        return $(this).val();        
     
     });
    
 var addData="";
        
        addData += "<tr><td><input type='text' id='member_name_modify"+i+"' name='member_name_modify"+i+"' placeholder='이름' maxlength='4' value='"+name_val+"'></td>";
            
        addData +="<td><input type='text' id='member_phone_modify"+i+"' name='member_phone_modify"+i+"' placeholder='전화번호(-제외)' maxlength='11', numberOnly='true' value='"+phone_val+"'></td>";
    
        addData +="<td colspan='2'><select id='payment_group_select_modify"+i+"' name='payment_group_select_modify"+i+"'>";
        
       for(i=0;i<group_select_text.length;i++){
        
        if(group_select_text[i]==select_val){
            
        addData +="<option selected>"+group_select_text[i]+"</option>"    
        }
        else{
        addData +="<option>"+group_select_text[i]+"</option>"
        
        }
       }
        addData +="</select></td></tr>";
       
       
       $("#member_modify_list").empty();
       $("#member_modify_list").append(addData).trigger("create");
        $('#member_modify').attr('href',"#modify-member")  
}




function modifyMemberListAll(){
    
    
  alert('멤버모두수정누름');
    
  var group_select_text=
        
     $('#payment_group_select0 option').map(function() {
        
        return $(this).val();        
     
     });
    
  var addData="";
  var j = $("#member_list tr").length;
 
  for (i=0;i<j;i++){
      
  var k = $('#member_list tr:nth-child('
            +(i+1)+')').attr('id').substring(7,10); 
      
  var name_val=$('#mt_memb'+k+' td:nth-child(1)').text();
  var phone_val=$('#mt_memb'+k+' td:nth-child(2)').text();   
  var select_val=$('#mt_memb'+k+' td:nth-child(3)').text();   
  
      
  addData += "<tr><td><input type='text' id='member_name_modify"+k+"' name='member_name_modify"+k+"' placeholder='이름' maxlength='4' value='"+name_val+"'></td>";
            
  addData +="<td><input type='text' id='member_phone_modify"+k+"' name='member_phone_modify"+k+"' placeholder='전화번호(-제외)' maxlength='11', numberOnly='true' value='"+phone_val+"'></td>";
    
  addData +="<td colspan='2'><select id='payment_group_select_modify"+k+"' name='payment_group_select_modify"+k+"'>";
        
  for(l=0;l<group_select_text.length;l++){
        
        if(group_select_text[l]==select_val){
            
        addData +="<option selected>"+group_select_text[l]+"</option>"    
        }
        else{
        addData +="<option>"+group_select_text[l]+"</option>"
        
        }
    }
    
    addData +="</select></td></tr>";
      
    
}
  
    $("#member_modify_list").empty();
    $("#member_modify_list").append(addData).trigger("create");
    $('#member_modify_all').attr('href',"#modify-member")                   
}


function deleteMember(i){
    
    alert('멤버삭제누름');
    
    if(confirm("해당 멤버를 삭제하시겠습니까?")==false){
    return false;
    }
        
    else{
        
        
         $.ajax({
                         url: '/mgmt_member/delete',
                         dataType : 'json',
                         type: "POST",
                         data: {memberID : i},                     
                         success: function(data){

                             console.log(data);

                            if (data.result =='success'){

                             alert('정상적으로 삭제되었습니다.');   
                             goToMtmember();  
                             }

                             else{
 
                             alert('알 수 없는 에러로 삭제에 실패했습니다');

                                 
                             }


                            }
            });
        
    }
    
                        
}


function deleteMemberAll(){
    
    if(confirm("모든 멤버를 삭제하시겠습니까?")==false){
    return false;
    
    }
        
    else{
    
        
        $.ajax({
                         url: '/mgmt_member/delete',
                         dataType : 'json',
                         type: "POST",
                         data: {memberID : 'all'},                     
                         success: function(data){

                             console.log(data);

                            if (data.result =='success'){

                              alert('정상적으로 삭제되었습니다.');   
                             goToMtmember();    
                             }

                             else{
 
                            alert('알 수 없는 에러로 삭제에 실패했습니다');

                                 
                             }


                            }
            });
    
        
    }
    

}


function deleteList(){
            
        
        if($('#new_member_list input:last').attr('id').substring(12,15)=="0"){
           
           alert('더이상 삭제할 수 없습니다');
           
        }
            
        else{
            
          $('#new_member_list input:last').remove();
          $('#new_member_list input:last').remove();
          $('#new_member_list select:last').remove();    
            
        }    
            
}
             
