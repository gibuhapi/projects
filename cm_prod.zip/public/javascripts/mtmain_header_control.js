function viewList() {


                $.ajax({
                         url: '/init_mt/view',
                         dataType : 'json',
                         type: "POST",
                         data: { },                  
                         success: function(data){

                              //console.log(data);

                    if(data.result == "success"){


                        $('#mt_list').empty(); 

                        var addlist="<br><br>"        

                        if(data.number=='0'){

                             addlist+="&nbsp;&nbsp;아직 모임이 없습니다 <br>&nbsp;&nbsp;왼쪽 추가를 터치해주세요";

                             $('#mt_list').append(addlist).trigger('create');
                             $('#mt_list').listview('refresh');        

                            }

                        else{

                            for(i=0;i<data.number;i++) {
 
                            addlist+="<li><a id=mt"+i+" onclick=goToMtmain("+i+")>"+data.mtdata[i].toString()+"</a></li>"; 

                            } 

                             $('#mt_list').append(addlist).trigger('create');
                             $('#mt_list').listview('refresh');



                            }
                        }
                    }

                });
 }



function addList(){
               
             if(!$('#addText input:last').attr('id')){
                
                i=0;
                //alert(i);            
             }
            
             else{
                
               i= $('#addText input:last').attr('id').substring(17,18);
               i++;
               //alert(i);
             }

               var addData="";
    
                 
                  if(i>4){ 
                    alert('5개 이상 추가할 수 없습니다.');
                    return false;
                 } 


                  else{ 

                    addData += "<tr><td><input type='text' id='mt_payment_group"+i+"' name='mt_payment_group"+i+"' maxlength='3' placeholder='등급'></td>";
                      
                    addData +="<td><input type='text' id='mt_payment_amount"+i+"' name='mt_payment_amount"+i+"' maxlength='8' placeholder='회비(숫자)' numberOnly='true'></td></tr>";
            
                    $("#addText").append(addData).trigger("create");
                    //$('#addText').listview('refresh');
                    
            
                    }
    
                   
                  
                  


}

function deleteList(){
            
        
        if(!$('#addText input:last').attr('id')){
           
           alert('추가한 열이 없습니다');
           
        }
            
        else{
            
          $('#addText input:last').remove();
          $('#addText input:last').remove();    
            
        }    
            
}

function modifyMt(){

        
    var mt_name_text= $("#mt_name").val();
    var cm_name_text= $("#cm_name").val();
    var cm_bankname_text= $("#cm_bankname").val();
    var cm_bankaccount_text= $("#cm_bankaccount").val(); 
    var mt_payment_dateno=$("#mt_payment_dateno").val();
               
    
    if($('input[name=mt_payment_date]').attr('type')=="text"){
                
            if((mt_name_text=="")||(cm_name_text=="")||(cm_bankname_text=="")||(cm_bankaccount_text=="")||(mt_payment_dateno=="")){        
                    
                   
                alert('모든 값을 입력해주세요');
                return false;
            }  
                    
            if(Number(mt_payment_dateno)>31||Number(mt_payment_dateno)<1){
                    
                alert('1~31일중에 선택해주세요');
                return false;
                    
            }    
    }
                    
    else{
               
            if((mt_name_text=="")||(cm_name_text=="")||(cm_bankname_text=="")||(cm_bankaccount_text=="")){            
                alert('모든 값을 입력해주세요');
                return false;
            }
    }
                
                
    if(!$('#addText input:last').attr('id')){
                    
            if(confirm('회비정보가 없는 상태로 모임을 만드시겠습니까?(+로 추가가능)')==false){ 
                
            return false; 
                
            }
    }

    else{
       
        j=Number($('#addText input:last').attr('id').substring(17,18))+1;
        
        for(i=0; i<j;i++){

        if(!($('#mt_payment_group'+i).val())||!($('#mt_payment_amount'+i).val())){

        alert(Number(i+1)+'번째 열의 회비값을 입력해주세요');
            
        return false;
        break;   
        
        }
        }
    
    
    }
    
        var mt_data= $('#modify_mt_form').serialize();

            $.ajax({
                    url: '/init_mt/modify',
                    dataType : 'json',
                    type: "POST",
                    data: mt_data,                     
                    
                    success: function(data){

                    //console.log(data);

                        if(data.result =="success"){
   
                         alert('정상적으로 수정되었습니다.');
                        
                            location.reload();
                        }
                             
                        else{
                                 
                         alert('알 수 없는 에러로 모임수정에 실패했습니다');

                        }

                           
                        }
                    });
                    
}     