function goToIndex(){
    
var form = document.createElement("form");     
         form.setAttribute("method","post");                    
         form.setAttribute("action","/");        
     
     document.body.appendChild(form);                         
      
     form.submit();      
    
}


function goToRegister(){
    
var form = document.createElement("form");     
         form.setAttribute("method","post");                    
         form.setAttribute("action","/register");        
     
     document.body.appendChild(form);                         
      
     form.submit();      
    
}

function goToRegisterM(){
    
var form = document.createElement("form");     
         form.setAttribute("method","get");                    
         form.setAttribute("action","/register/modify");        
     
     document.body.appendChild(form);                         
      
     form.submit();      
    
}


function goToMain(){

     var form = document.createElement("form");     
         form.setAttribute("method","post");                    
         form.setAttribute("action","/main");        
     
     document.body.appendChild(form);                         
      
     form.submit();        
}

function goToMtmain(mt_data){

         var form = document.createElement("form");     
             form.setAttribute("method","post");                    
             form.setAttribute("action","/mgmt_mt/mt_main");        

         document.body.appendChild(form);                         

         var value1= document.createElement("input"); 
         value1.setAttribute("type","hidden");
         value1.setAttribute("name", "mt_number");  
         value1.setAttribute("value", mt_data);
         form.appendChild(value1);
         
         form.submit();  

}

 function goToMtmember(){


         var form = document.createElement("form");     
             form.setAttribute("method","post");                    
             form.setAttribute("action","/mgmt_mt/mt_member");        

         document.body.appendChild(form);                         

         form.submit();  

}    

 function goToMtevent(){


         var form = document.createElement("form");     
             form.setAttribute("method","post");                    
             form.setAttribute("action","/mgmt_mt/mt_event");        

         document.body.appendChild(form);                         

         form.submit();  

}    

 function goToMtrevenue(){

         var form = document.createElement("form");     
             form.setAttribute("method","post");                    
             form.setAttribute("action","/mgmt_mt/mt_revenue");        

         document.body.appendChild(form);                         

         form.submit();  


}  


function goToLogout(){
    
var form = document.createElement("form");     
         form.setAttribute("method","post");                    
         form.setAttribute("action","/logout");        
     
     document.body.appendChild(form);                         
      
     form.submit();      
    
}

