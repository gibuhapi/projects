function mtmemberControl(mt_payment_data,mt_member_data){
 
    var paymentText1=""; 
    var paymentText2="";
    var memberText="";
    
    if(mt_payment_data.length>0){
        
     for(i=0;i<mt_payment_data.length;i++){    
      
          switch (i%3){
         
          case 0:
          paymentText1+="<option>"
          paymentText1+=mt_payment_data[i];
          paymentText1+="</option>"; 
              
          paymentText2+="<tr><td>"
          paymentText2+=mt_payment_data[i];
          paymentText2+="</td>"           
          break;
         
          case 1:
             
          paymentText2+="<td colspan='2'>"
          paymentText2+=mt_payment_data[i];
          paymentText2+="</td>"       
          break;
                  
          case 2:
             
          paymentText2+="<td>"
          paymentText2+=mt_payment_data[i];
          paymentText2+="명</td><tr>"       
          break;          
                  
                  
         }
    }
        
    $("#payment_group_select0").append(paymentText1).trigger('create');
    $("#payment_list").append(paymentText2).trigger('create');      
    }
         
    else{
        
        PaymentData1+="<option>없음</option>"
        $("#payment_group_select0").append(paymentText1).trigger('create');
        paymentText+="<tr><td colspan='4'>일반<td><tr>"
        $("#payment_list").append(paymentText2).trigger('create'); 
    
    }
         
         
     if(mt_member_data.length>1){
        
     for(i=0;i<mt_member_data.length;i++){    
      
          switch (i%4){
         
          case 0:
          memberText+="<tr id='mt_memb"
          memberText+=mt_member_data[i];
          memberText+="'>"; 
                
          break;
         
          case 1:
             
          memberText+="<td>"
          memberText+=mt_member_data[i];
          memberText+="</td>"       
          break;
                  
          case 2:
             
          memberText+="<td>"
          memberText+=mt_member_data[i];
          memberText+="</td>"       
          break; 
                  
          case 3:
             
          memberText+="<td>"
          memberText+=mt_member_data[i];
          memberText+="</td></tr>"       
          break;           
                  
                  
         }
    }
     $("#member_list").append(memberText).trigger('create');      
    }
         
    else{
        
        memberText+="<tr><td>&nbsp;</td></tr><tr><td colspan='4'>데이터가 없습니다<td><tr>"
        $("#member_list").append(memberText).trigger('create'); 
    
    }     
}


