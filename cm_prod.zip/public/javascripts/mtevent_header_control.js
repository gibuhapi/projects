function viewList() {


                $.ajax({
                         url: '/init_mt/view',
                         dataType : 'json',
                         type: "POST",
                         data: { },                  
                         success: function(data){

                              console.log(data);

                    if(data.result == "success"){


                        $('#mt_list').empty(); 

                        var addlist="<br><br>"        

                        if(data.number=='0'){

                             addlist+="&nbsp;&nbsp;아직 모임이 없습니다 <br>&nbsp;&nbsp;왼쪽 추가를 터치해주세요";

                             $('#mt_list').append(addlist).trigger('create');
                             $('#mt_list').listview('refresh');        

                            }

                        else{

                            for(i=0;i<data.number;i++) {
 
                            addlist+="<li><a id=mt"+i+" onclick=goToMtmain("+i+")>"+data.mtdata[i].toString()+"</a></li>"; 

                            } 

                             $('#mt_list').append(addlist).trigger('create');
                             $('#mt_list').listview('refresh');



                            }
                        }
                    }

                });
 }