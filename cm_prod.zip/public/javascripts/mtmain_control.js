function mtmainControl(mt_payment_data){
 
     var payment_text1="";
     var payment_text2="";   

    
    if(mt_payment_data.length>1){

            for(i=0;i<mt_payment_data.length;i++) {

               if((i%2)==0) {

                  payment_text1+= "<tr><td>";   
                  payment_text1+= mt_payment_data[i];
                  payment_text1+= "</td>";

                  payment_text2+= "<tr><td><input type='text' id='mt_payment_group"+parseInt(i/2)+"' name='mt_payment_group"+parseInt(i/2)+"' maxlength='3' placeholder='등급' value='"
                  payment_text2+= mt_payment_data[i];
                  payment_text2+= "'></td>"; 
                  
               }

               else {

                  payment_text1 +="<td>";        
                  payment_text1+= mt_payment_data[i];
                  payment_text1+= "</td></tr>";

                  payment_text2+= "<td><input type='text' id='mt_payment_amount"+parseInt(i/2)+"' name='mt_payment_amount"+parseInt(i/2)+"' maxlength='8' placeholder='회비(숫자)' numberOnly='true' value='"
                  payment_text2+= mt_payment_data[i];
                  payment_text2+= "'></td></tr>"; 
                   
               }     
            }

            $('#mt_payment_list').append(payment_text1).trigger('create');  
             $('#addText').append(payment_text2).trigger('create'); 
             //$('#addText').listview('refresh');    

        }     

         else {

             payment_text1+="<tr><td>&nbsp;</td></tr><tr><td colspan=4>";     
             payment_text1+=" 아직 설정된 등급이 없습니다</td><tr>";
            $('#mt_payment_list').append(payment_text1).trigger('create');             
         }

}


function deleteMt(){

            $.ajax({
                url: '/mgmt_mt/delete',
                dataType : 'json',
                type: "POST",
                data: {},

                success: function(data){

                    if(data.result=='success'){
                    alert('모임이 정상적으로 삭제되었습니다');
                    goToMain();
                    }

                    else if(data.result=='false'){
                    alert('삭제할 모임이 없습니다');    
                    }

                    else {

                    alert('서버와의 연결이 끊어졌습니다');    

                    }
                }
              });     
    
   
    
}