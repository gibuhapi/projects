function mteventControl(mt_event_data,mt_event_data_past){
 
     var mt_event_text="";
     var mt_event_text_past="";
        
        if(mt_event_data.length>1){   

            for(i=0;i<mt_event_data.length;i++) {

               switch (i%7) {        
                
                case 0:
                mt_event_text+="<tr id='mt_event"+mt_event_data[i]+"'> <td>";       
                break;       
                     
                case 1:      
                mt_event_text+=mt_event_data[i];
                break;
                     
                case 2:
                mt_event_text+=" ("+mt_event_data[i]+")";
                mt_event_text+='</td>';            
                break;
                       
                case 3: 
                mt_event_text+='<td>'
                mt_event_text+=mt_event_data[i];
                mt_event_text+='</td>';          
                break;
                
                case 4: 
                mt_event_text+='<td>'
                mt_event_text+=mt_event_data[i];
                mt_event_text+='</td>';          
                break;
                       
                case 5: 
                mt_event_text+='<td>'
                mt_event_text+=mt_event_data[i];
                mt_event_text+='</td>';          
                break;
                
                case 6: 
                
                if(mt_event_data[i]){       
                mt_event_text+="<td><a target='_blank' href='";
                mt_event_text+=mt_event_data[i];
                mt_event_text+="'>"+mt_event_data[i]+"</a></td></tr><tr><td>&nbsp;<tr>";          
                }
                else{
                mt_event_text+="<td>";
                mt_event_text+="링크없음";
                mt_event_text+="<td></tr><tr><td>&nbsp;<tr>";    
                    
                }
                break;
                       
                }   
            }   

            $('#event_list').empty();
            $('#event_list').append(mt_event_text).trigger('create');
            //$('#event_list').table('refresh');    

        }    
        
        else {
               mt_event_text+='<tr><td>';
               mt_event_text+='생성된 행사가 없습니다';
               mt_event_text+='<td></tr>';
               $('#event_list').append(mt_event_text).trigger('create');
              // $('#event_list').table('refresh');     
        
            }
    
    
    
       if(mt_event_data_past.length>1){   

            for(i=0;i<mt_event_data_past.length;i++) {

               switch (i%7) {        
                
                case 0:
                mt_event_text_past+="<tr id='mt_event_past"+mt_event_data_past[i]+"'> <td>";       
                break;       
                     
                case 1:      
                mt_event_text_past+=mt_event_data_past[i];
                break;
                     
                case 2:
                mt_event_text_past+=" ("+mt_event_data_past[i]+")";
                mt_event_text_past+='</td>';            
                break;
                       
                case 3: 
                mt_event_text_past+='<td>'
                mt_event_text_past+=mt_event_data_past[i];
                mt_event_text_past+='</td>';          
                break;
                
                case 4: 
                mt_event_text_past+='<td>'
                mt_event_text_past+=mt_event_data_past[i];
                mt_event_text_past+='</td>';          
                break;
                       
                case 5: 
                mt_event_text_past+='<td>'
                mt_event_text_past+=mt_event_data_past[i];
                mt_event_text_past+='</td>';          
                break;
                
                case 6: 
                
                if(mt_event_data[i]){       
                mt_event_text_past+="<td><a target='_blank' href='";
                mt_event_text_past+=mt_event_data_past[i];
                mt_event_text_past+="'>"+mt_event_data_past[i]+"</a></td></tr><tr><td>&nbsp;<tr>";          
                }
                else{
                mt_event_text_past+="<td>";
                mt_event_text_past+="링크없음";
                mt_event_text_past+="<td></tr><tr><td>&nbsp;<tr>";    
                    
                }
                break;
                       
                }   
            }   

            $('#event_list_past').empty();
            $('#event_list_past').append(mt_event_text_past).trigger('create');
            //$('#event_list').table('refresh');    

        }    
        
        else {
               mt_event_text_past+='<tr><td>';
               mt_event_text_past+='지난 행사가 없습니다';
               mt_event_text_past+='<td></tr>';
               $('#event_list_past').append(mt_event_text_past).trigger('create');
              // $('#event_list').table('refresh');     
        
            }

}

function createEvent(){

    
        var event_data= $("#event_create_form").serializeArray();
        
        var mt_event_name= $("#event_name").val();
        var mt_event_round= $("#event_round").val();
        var mt_event_date= $("#event_date").val();
        var mt_event_time= $("#event_time").val();
        var mt_event_location= $("#event_location").val(); 
        var mt_event_url= $("#event_url").val();         
        
        if(mt_event_name==""){
            alert('행사명을 입력해주세요');
            return false;
            }
    
         
        else if(mt_event_date==""){
            alert('행사 차수를 선택해주세요');
            return false;    
            }
    
         
        else if(mt_event_date==""){
            alert('행사 날짜를 선택해주세요');
            return false;    
            }
    
        
        else if(event_time==""){
            alert('행사 시간을 선택해주세요');
            return false;    
            }
    
        else {   
            
            if(mt_event_url){
            
            var bitLink="https://api-ssl.bitly.com/v3/shorten?";    
            var urlEncoded = encodeURI(mt_event_url);
            
            //console.log(urlEncoded);
                 
                $.getJSON(bitLink,{access_token: "a5b39ca8373515e63ae72a2f99154f0c67b8f530", longUrl: urlEncoded},function(data){

                    if(data.status_code=="200"){

                        event_data.forEach(function (item) {

                        if (item.name === 'event_url') {
                        item.value = data.data.url; 
                        }
                            
                    });
                        
                }         
                    $.ajax({
                    url: '/mgmt_event/create',
                    dataType : 'json',
                    type: "POST",
                    data: $.param(event_data),               
                    success: function(data){

                    console.log(data);

                            if (data.result =='error'){
                            alert('알수없는 에러로 저장하지 못했습니다');    
                            }

                            else{

                          
                           alert('정상적으로 저장되었습니다');
                          
                            location.reload();          
                            
                            }

    
                        }

                });

            });
                
        }
            
        else{
            
            
            $.ajax({
                url: '/mgmt_event/create',
                dataType : 'json',
                type: "POST",
                data: $.param(event_data),               
                success: function(data){

                console.log(data);

                        if (data.result =='error'){
                        alert('알수없는 에러로 저장하지 못했습니다');    
                        }

                        else{

                        alert('정상적으로 저장되었습니다');    
                        location.reload(); 
                            
                        }


                    }

            }); 
            
  
            
        }
    
    }
    
}

function modifyEvent(){

    
        var event_data= $("#event_modify_form").serializeArray();
        console.log(event_data);
    
        var mt_event_name= $("#event_name_modify").val();
        var mt_event_round= $("#event_round_modify").val();
        var mt_event_date= $("#event_date-modify").val();
        var mt_event_time= $("#event_time_modify").val();
        var mt_event_location= $("#event_location_modify").val(); 
        var mt_event_url= $("#event_url_modify").val();         
        
        if(mt_event_name==""){
            alert('행사명을 입력해주세요');
            return false;
            }
    
         
        else if(mt_event_date==""){
            alert('행사 차수를 선택해주세요');
            return false;    
            }
    
         
        else if(mt_event_date==""){
            alert('행사 날짜를 선택해주세요');
            return false;    
            }
    
        
        else if(event_time==""){
            alert('행사 시간을 선택해주세요');
            return false;    
            }
    
        else {
    
        if(mt_event_url){
            
            var bitLink="https://api-ssl.bitly.com/v3/shorten?"; var urlEncoded = encodeURI(mt_event_url);
 
                $.getJSON(bitLink,{access_token: "a5b39ca8373515e63ae72a2f99154f0c67b8f530", longUrl: urlEncoded},function(data){
                        
                    if(data.status_code=="200"){
                               
                        event_data.forEach(function (item) {

                        if (item.name === 'event_url') {
                        item.value = data.data.url; 
                        }

                    });
                        
                    }   
    
                    $.ajax({
                        url: '/mgmt_event/modify',
                        dataType : 'json',
                        type: "POST",
                        data: $.param(event_data),               
                        success: function(data){

                        console.log(data);

                            if (data.result =='error'){
                            alert('알수없는 에러로 저장하지 못했습니다');    
                            }

                            else{

                           alert('정상적으로 수정되었습니다');  
                           location.reload();         

                            }

                                    
                        }

                        });

                });


            }
            
            
        else{
            
            $.ajax({
                url: '/mgmt_event/modify',
                dataType : 'json',
                type: "POST",
                data: $.param(event_data),               
                success: function(data){

                console.log(data);

                        if (data.result =='error'){
                        alert('알수없는 에러로 저장하지 못했습니다');    
                        }

                        else{

                        alert('정상적으로 수정되었습니다');  
                        location.reload();           

                        }

                                 
                    }

            });
            
            
            
        }
            
    }
    
}

function deleteEvent(i){

    
                $.ajax({
                url: '/mgmt_event/delete',
                dataType : 'json',
                type: "POST",
                data: {event_number : i},
                    
                success: function(data){

                console.log(data);

                        if (data.result =='error'){
                        alert('알수없는 에러로 삭제하지 못했습니다');    
                        }

                        else{

                        alert('정상적으로 삭제되었습니다');  
                         location.reload();   

                        }

                    
                }

            });

}

function viewEvent(i){
    
    
        $.ajax({
                    url: '/mgmt_event/select',
                    dataType : 'json',
                    type: "POST",
                    data: { event_number : i },                  
                         success: function(data){
                    
                    console.log(data);
                    if(data.event_data){
                       
                    $("#event_number").val(data.event_data[0]);
                    $("#event_name_modify").val(data.event_data[1]); $("#event_round_modify").val(data.event_data[2]);
                    $("#event_date_modify").val(data.event_data[3]);
                    $("#event_time_modify").val(data.event_data[4]);     
                    $("#event_time_modify>option:contains("+ data.event_data[4]+")").attr("selected","selected"); 
                    //$("#event_location_modify").val(data.event_data[5]); 
                    $("#event_url_modify").val(data.event_data[6]);         
                    
                
                         
            }
                             
        }
              
    });      
    
}



