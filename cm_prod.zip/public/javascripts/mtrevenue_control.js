function mtrevenueControl(mt_memb_data,mt_event_data){
 
     var mt_plus_text="";
     var mt_event_text="";
     
    
        if(mt_memb_data.length>1){   

        for(i=0;i<mt_memb_data.length;i++) {
            
               
            switch (i%6){
                    
            case 0:
            var yn= mt_memb_data[i];        
            break;  
                    
            //회원번호
            case 1:
            mt_plus_text+="<tr id='mt_memb"+mt_memb_data[i]+"'>";
            mt_plus_text+="<input type='hidden' name='mt_memb"+mt_memb_data[i]+"'";       
            break;       
            
            //이름         
            case 2:   
            mt_plus_text+="value='"+mt_memb_data[i]+"'><td style='text-align: center;'>";
            mt_plus_text+=mt_memb_data[i]+"</td><td style='text-align: center;'>";
            break;
            
            /*예정액*/          
            case 3:  
        
            mt_plus_text+=mt_memb_data[i]+"</td><td style='text-align: center;'>";
            break;
                    
            /*납부액*/        
            case 4:
                    
            if(yn=="Y"){
                    
            mt_plus_text+="<input type='text' name='mt_memb"+ mt_memb_data[i-3]+"'" +"value='"+mt_memb_data[i]+"' numberOnly='true' placeholder='숫자만'></td><td style='text-align: center;'><input type='checkbox' name='mt_memb"+ mt_memb_data[i-3]+"' checked></td>";  
            mt_plus_text+="<input type='hidden' name='mt_memb"+ mt_memb_data[i-3]+"' readOnly value="+mt_memb_data[i+1]+"></tr>";
                 
                 
            }
            
            else{
                    
             mt_plus_text+="<input type='text' name='mt_memb"+ mt_memb_data[i-3]+"'" +"value='"+mt_memb_data[i]+"' numberOnly='true' placeholder='숫자만'></td><td style='text-align: center;'><input type='checkbox' name='mt_memb"+ mt_memb_data[i-3]+"' ></td>";
             mt_plus_text+="<input type='hidden' name='mt_memb"+ mt_memb_data[i-3]+"' readOnly value="+mt_memb_data[i+1]+"></tr>";    
            }        
                       
            break;
                    
                    
            
            }
        }
        
        $('#plus_list').empty();
        $('#plus_list').append(mt_plus_text).trigger('create');
            //$('#event_list').table('refresh');    
        }
       
        else {
            
         $('#plus_list').empty();      
       
    }
            
  
    if(mt_event_data.length>1){ 
        
        

        for(i=0;i<mt_event_data.length;i++) {

            switch (i%6) {        
                
            case 0:
                    
            mt_event_text+="<tr id='mt_event"+mt_event_data[i]+"'><td style='text-align: center;'>";     
            mt_event_text+="<input type='hidden' name='mt_event"+mt_event_data[i];  
            break;       
                     
            case 1: 
                    
            mt_event_text+="' value='"+mt_event_data[i]+"'>";
            mt_event_text+=mt_event_data[i]+"</td>";        
            mt_event_text+="<td style='text-align: center;'>";
            mt_event_text+="<input type='hidden' name='mt_event"+mt_event_data[i-1];
            break;
                     
            case 2:
            mt_event_text+="' value='"+mt_event_data[i]+"'>";        
            mt_event_text+=mt_event_data[i]+"</td><td style='text-align: center;'>"; 
            mt_event_text+="<input type='hidden' name='mt_event"+mt_event_data[i-2];        
                
            break;
            
            case 3:
            mt_event_text+="' value='"+mt_event_data[i]+"'>";               
            mt_event_text+=mt_event_data[i]+"</td><td style='text-align: center;'>";          
            mt_event_text+="<input type='text' name='mt_event"+     mt_event_data[i-3]+"' numberOnly='true' value=";   
            break;
                    
            case 4:
            mt_event_text+=mt_event_data[i]+"></td>"; 
            mt_event_text+="<input type='hidden' name='mt_event"+ mt_event_data[i-4]+"' readOnly value='"+mt_event_data[i+1]+"'></tr>";             
            break;        
            }
    }
            
           
            
            $('#event_list').empty();
            $('#event_list').append(mt_event_text).trigger('create');
            //$('#event_list').table('refresh');    
        
        

    }    
        
    else {
            
            $('#event_list').empty(); 
        } 
    
    

}
    
    
    

function addPlusList(i,date){
       
    
       if(date.substring(0,7)!==$("#revenue_date").text().replace(/ /gi, "").replace("년","-").replace("월","")){
            
         var date= $("#revenue_date").text().replace(/ /gi, "").replace("년","-").replace("월","").trim()+"-01";    
            
        }
    
       var mt_plus_text="<tr id='mt_etc"+i+"'><td><input type='text' name='mt_etc"+i+"'></td><td style='text-align: center;'>0</td><td style='text-align: center;'><input type='text' name='mt_etc"+i+"'  value=0 numberOnly='true' placeholder='숫자만' ></td><td style='text-align: center;'><input type='checkbox' name='mt_etc"+i+"'></td><input type='hidden' name='mt_etc"+i+"' readOnly value="+date+"></tr>";    
       
        $('#plus_list').append(mt_plus_text).trigger('create');
        i++;
     
    
}

function deletePlusList(mt_memb_data){
    
       var number = (mt_memb_data.length)/6;

    
       if($('#plus_list tr').length == number){
           
           alert('더이상 삭제할 수 없습니다');
           
        }
            
        else{
            
          $('#plus_list tr:last').remove();
           
        }  
    
}


function savePlusList(){
    
     
    /*if($( "#plus_list input:checked" ).length==0){
             
     alert('체크된 값이 없습니다');
     return false; 
     }
    */
    
    var j =$('#plus_list input').length;
   
    
    for(i=0;i<j;i++){
        
    if(!$('#plus_list input:eq('+i+')').val()){
        
    alert('입력되지 않은 값이 있습니다');
    return false;
    }    
    }
    
    var revenue_data= $("#revenue_plus_form").serialize();             
    console.log(revenue_data); 
            $.ajax({
                    url: '/mgmt_revenue/plus',
                    dataType : 'json',
                    type: "POST",
                    data: revenue_data,                     
                    success: function(data){

                        if(data.result =="success"){

                            alert('정상적으로 저장되었습니다.');
                            location.reload();

                        }

                
                        else{

    
                             alert('알수없는 에러로 실패하였습니다');     
                        }


                    }
                });
    
    
   
    //var revenue_date =$('#revenue_date').text();
    //var dateChanged = revenue_date.replace(/ /gi, "").replace("년","-").replace("월","").trim();
    
   
    
}


function addMinusList(i,date){
    
        
    
    
    
    
    
        if(date.substring(0,7)!==$("#revenue_date").text().replace(/ /gi, "").replace("년","-").replace("월","")){
            
         var date= $("#revenue_date").text().replace(/ /gi, "").replace("년","-").replace("월","").trim()+"-01";    
            
        }
    
        var mt_event_text="<tr id='mt_etc"+i+"'><td style='text-align: center;'><input type='text' name='mt_etc"+i+"' maxlength='8'></td><td style='text-align: center;'><input type='text'  value='기타' name='mt_etc"+i+"'></td><td><input type='text' name='mt_etc"+i+"'></td><td style='text-align: center;'><input type='text' name='mt_etc"+i+"' numberOnly='true' value=0></td><input type='hidden' name='mt_etc"+i+"' readOnly value="+date+"></tr>"
         
      
        $('#event_list').append(mt_event_text).trigger('create');
    
        i++;
    
    
    
}

function deleteMinusList(mt_event_data){
    
        var number = (mt_event_data.length)/6;
    
        if($('#event_list tr').length == number){
           
           alert('더이상 삭제할 수 없습니다');
           
        }
            
        else{
            
          $('#event_list tr:last').remove();
            
        }  
    
    
    
}



function saveMinusList(){
    

    
    var j =$('#event_list input').length;
    alert(j);
    
    for(i=0;i<j;i++){
        
    if(!$('#event_list input:eq('+i+')').val()){
        
    alert('입력되지 않은 값이 있습니다');
    return false;
    }    
    }
    
    
    var revenue_data= $("#revenue_minus_form").serialize();
    //var revenue_date =$('#revenue_date').text();
    //var dateChanged = revenue_date.replace(/ /gi, "").replace("년","-").replace("월","").trim();
    
    console.log(revenue_data);
    
            $.ajax({
                    url: '/mgmt_revenue/minus',
                    dataType : 'json',
                    type: "POST",
                    data: revenue_data,
                    success: function(data){

                        if(data.result =="success"){

                            alert('정상적으로 저장되었습니다.');
                            
                            location.reload();

                        }

                
                        else{

    
                             alert('알수없는 에러로 실패하였습니다');     
                        }


                    }
                });
    
    
}

function goPrevious(){
    
alert('저번달로 가기 클릭함');
    
    
var revenue_date= $("#revenue_date").text();                
var dateChanged = revenue_date.replace(/ /gi, "").replace("년","-").replace("월","").trim();
    
    
    $.ajax({
                    url: '/mgmt_revenue/view',
                    dataType : 'json',
                    type: "POST",
                    data: {date : dateChanged,change: -1},                   
                    success: function(data){

                    if(data.result =="success"){

                            
                    $('#revenue_date').text(data.now.substring(0,4)+"년 "+data.now.substring(5,7)+"월");
                    $("#month_profit_search").text(data.revenue_data[0]);
                    $("#month_expense_search").text(data.revenue_data[1]);
                
                    mtrevenueControl(data.memb_data,data.event_data);       
                    
                    var date= $("#revenue_date").text().replace(/ /gi, "").replace("년","-").replace("월","").trim()+"-01";
                    

                        }

                
                        else{

    
                             alert('알수없는 에러로 실패하였습니다');     
                        }


                    }
                });
    
    
}

function goNext(){
    

alert('다음달로 가기 클릭함');
    
    
var revenue_date= $("#revenue_date").text();                
var dateChanged = revenue_date.replace(/ /gi, "").replace("년","-").replace("월","").trim();
    
    
    $.ajax({
                    url: '/mgmt_revenue/view',
                    dataType : 'json',
                    type: "POST",
                    data: {date : dateChanged,change: 1},                     
                    success: function(data){

                   if(data.result =="success"){

                            
                    $('#revenue_date').text(data.now.substring(0,4)+"년 "+data.now.substring(5,7)+"월");
                    $("#month_profit_search").text(data.revenue_data[0]);
                    $("#month_expense_search").text(data.revenue_data[1]);
                
                    mtrevenueControl(data.memb_data,data.event_data);       
                    
                    var date= $("#revenue_date").text().replace(/ /gi, "").replace("년","-").replace("월","").trim()+"-01";
                    

                        }

                
                        else{

    
                             alert('알수없는 에러로 실패하였습니다');     
                        }


                    }
                });
}

function replaceComma(x) {
   
    if(x){
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    else{
    return 0;    
    }

}




function deleteRevenue(id){
    
    
    var revenue_date= $("#revenue_date").text();                
    var dateChanged = revenue_date.replace(/ /gi, "").replace("년","-").replace("월","").trim();
    
            $.ajax({
                    url: '/mgmt_revenue/delete',
                    dataType : 'json',
                    type: "POST",
                    data: {id: id,date: dateChanged},                success: function(data){

                        if(data.result =="success"){

                            alert('정상적으로 삭제되었습니다.');
                            location.reload();

                        }

                
                        else{

    
                             alert('알수없는 에러로 실패하였습니다');     
                        }


                    }
                });
    
}


    
      