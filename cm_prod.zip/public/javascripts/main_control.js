function mainControlEvent(mt_event_data){
 
    var mt_event_text=""; 
        
     if(mt_event_data.length>1) {
       
            for(i=0;i<mt_event_data.length;i++) {

            switch (i%4) {        
                
                case 0:      
                mt_event_text+="<tr id='mt_event"+parseInt(i/4)+"'><td>";
                mt_event_text+=mt_event_data[i];
                mt_event_text+='</td>';    
                break;
                       
                case 1:      
                mt_event_text+="<td>";
                mt_event_text+=mt_event_data[i];
                break;
                     
                case 2:
                mt_event_text+=" ("+mt_event_data[i]+")";
                mt_event_text+='</td>';            
                break;
                       
                case 3: 
                mt_event_text+='<td>'
                mt_event_text+=mt_event_data[i];
                mt_event_text+='</td></tr><tr><td>&nbsp;</td></tr>';          
                break;    
            }   
        }
         
         $('#event_list').append(mt_event_text).trigger('create');
        
            
    }

    
    
     else{   

     
        mt_event_text+='<tr><td>';
        mt_event_text+='예정된 행사가 현재 없습니다';
        mt_event_text+='<td></tr>';
       
        $('#event_list').append(mt_event_text).trigger('create');
        
        }
             
}



function mainControlRevenue(mt_revenue_date,mt_revenue_data){
 
    
    $("#p_previous_month").text(mt_revenue_date[0]);
    $("#previous_month").text(mt_revenue_date[1]);
    $("#now_month").text(mt_revenue_date[2]);
    
   
    
    $("#p_previous_past").text(replaceComma(mt_revenue_data[0]));           $("#p_previous_change").text(replaceComma(Number(mt_revenue_data[1])-Number(mt_revenue_data[2])));
 $("#p_previous_result").text(replaceComma(Number(mt_revenue_data[0])+Number(mt_revenue_data[1])-Number(mt_revenue_data[2]))); 
    
     $("#previous_past").text(replaceComma(mt_revenue_data[3]));           $("#previous_change").text(replaceComma(Number(mt_revenue_data[4])-Number(mt_revenue_data[5])));
 $("#previous_result").text(replaceComma(Number(mt_revenue_data[3])+Number(mt_revenue_data[4])-Number(mt_revenue_data[5])));
                    
   
    $("#now_past").text(replaceComma(mt_revenue_data[6]));
    $("#now_change").text(replaceComma(Number(mt_revenue_data[7])-Number(mt_revenue_data[8])));
   $("#now_result").text(replaceComma(Number(mt_revenue_data[6])+Number(mt_revenue_data[7])-Number(mt_revenue_data[8])));          
        
            
    }

function getChartData(mt_revenue_date,mt_revenue_data){
    
  
    
    var chartData = {
            labels:  //window.chartData,
            mt_revenue_date,
            datasets: [
            
            {
                type: 'line',
                label: '+',
                borderColor: window.chartColors.black,
                borderWidth: 2,
                fill: false,
                data: [
                   Number(mt_revenue_data[0])+Number(mt_revenue_data[1])-Number(mt_revenue_data[2]),
                   Number(mt_revenue_data[3])+Number(mt_revenue_data[4])-Number(mt_revenue_data[5]),
                   Number(mt_revenue_data[6])+Number(mt_revenue_data[7])-Number(mt_revenue_data[8])
                    ]
            },    
                
            {
                type: 'bar',
                label: '수입',
                backgroundColor: window.chartColors.blue,
                data: [
                    mt_revenue_data[1],
                    mt_revenue_data[4],
                    mt_revenue_data[7],
                ],
                borderColor: 'white',
                borderWidth: 1
            }, 
            {
                type: 'bar',
                abel: '지출',
                backgroundColor: window.chartColors.red,
                data: [
                    mt_revenue_data[2],
                    mt_revenue_data[5],
                    mt_revenue_data[8],
                ],
                borderColor: 'white',
                borderWidth: 1
            }
            
            ]

        }
    
    return chartData;
    
     
    
    
}


function replaceComma(x) {
   
    if(x){
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ",");
    }
    else{
    return 0;    
    }

}


function goPreviousMeeting(mt_number){
    
 
    
     var mt_name_index = $('#mt_revenue_summary td:nth-child(2)').attr('id');
    
    if(mt_number=='1'){
        
    alert('이전 모임이 없습니다');    
        
    }
    
    

    else if(mt_name_index =='-1'){
       
   alert('모임을 생성해주세요');
       
    }
    
    else{
        
    $.ajax({
            url: '/main/viewOtherRevenue',
            dataType : 'json',
            type: "POST",
            data: {index: mt_name_index,direction: -1},  
            success: function(data){

                
           $('#meeting_name').text(data.mt_name); 
           $('#mt_revenue_summary td:nth-child(2)').attr('id',data.mt_name_index);        
                
           mainControlRevenue(data.mt_revenue_date,data.mt_revenue_data); 
            window.myMixedChart = new Chart($('#canvas'), {
                type: 'bar',
                data: getChartData(data.mt_revenue_date,data.mt_revenue_data),
                //chartData,
                options: {
                    
                    responsive: true,
                    elements: {
                        point: {
                            pointStyle: 'rect'
                        }
                    },
                    
                    legend: {
                    display: false
                    },
                    tooltips: {
                    callbacks: {
                    label: function(tooltipItem) {
                        
                        return tooltipItem.yLabel;
                    }
                    }
                    },
                    title: {
                        display: false,
                    },
                    tooltips: {
                        enabled :false,
                        mode: 'index',
                        intersect: false
                    }
                }
            });
                
            window.myMixedChart.update();    
                
                
                

            }
    });    
        
    }
}
        

function goNextMeeting(mt_number){
    
    var mt_name_index = $('#mt_revenue_summary td:nth-child(2)').attr('id');
    
    if(mt_number=='1'){
        
    alert('이전 모임이 없습니다');    
        
    }
    
    

    else if(mt_name_index =='-1'){
       
   alert('모임을 생성해주세요');
       
    }
    
    else{
        
    $.ajax({
            url: '/main/viewOtherRevenue',
            dataType : 'json',
            type: "POST",
            data: {index: mt_name_index,direction: 1},  
            success: function(data){

                
           $('#meeting_name').text(data.mt_name); 
           $('#mt_revenue_summary td:nth-child(2)').attr('id',data.mt_name_index);        
                
           mainControlRevenue(data.mt_revenue_date,data.mt_revenue_data); 
            window.myMixedChart = new Chart($('#canvas'), {
                type: 'bar',
                data: getChartData(data.mt_revenue_date,data.mt_revenue_data),
                //chartData,
                options: {
                    
                    responsive: true,
                    elements: {
                        point: {
                            pointStyle: 'rect'
                        }
                    },
                    
                    legend: {
                    display: false
                    },
                    tooltips: {
                    callbacks: {
                    label: function(tooltipItem) {
                        
                        return tooltipItem.yLabel;
                    }
                    }
                    },
                    title: {
                        display: false,
                    },
                    tooltips: {
                        enabled :false,
                        mode: 'index',
                        intersect: false
                    }
                }
            });
                
            window.myMixedChart.update();    
                
                
                

            }
    });    
        
    }
}